//============================================================================
// Name        : main.cpp
//============================================================================

#include <iostream>
using namespace std;

int main() {
	// Ez a program demonstralja a valtozok es a memoria kapcsolatat

	cout << "1. ora 1. demonstracio - Valtozok" << endl;

	int     i = 5;    // Valtozo sajat memoriaterulettel
	cout << "Az i memoriacime " << &i << " es a memoriaterulet tartalma " << i << endl;
	int &   r = i;    // Referencia az elozo valtozora
	cout << "Az r memoriacime " << &r << " es a memoriaterulet tartalma " << r << endl;

	int *   p = &i;   // Pointer az elozo memoriateruletre
	cout << "A  p memoriacime " << &p << " es a memoriaterulet tartalma " << p << endl;
	cout << "A  p altal hivatkozott memoriaterulet cime " << (&(*p)) << " es annak tartalma " << (*p) << endl;

	cout << "Vegyuk eszre, hogy az eredeti valtozo es a referencia ugyanazon a cimen dolgozik" << endl;
	cout << "Vegyuk eszre, hogy a pointer altal tarolt cim pontosan az a cim, ami az i valtozo cime" << endl;
	cout << "Tovabba, nezzuk meg azt is, hogy a pointer teljesen mas cimen talalhato" << endl;

	cout << "---------------------------------------------------" << endl;
	cout << "Valtoztassuk meg az ertekeket";
	i++;
	cout << "Az i memoriacime " << &i << " es a memoriaterulet tartalma " << i << endl;
	cout << "Az r memoriacime " << &r << " es a memoriaterulet tartalma " << r << endl;
	cout << "A  p memoriacime " << &p << " es a memoriaterulet tartalma " << p << endl;
	cout << "A  p altal hivatkozott memoriaterulet cime " << (&(*p)) << " es annak tartalma " << (*p) << endl;
	cout << "---------------------------------------------------" << endl;
	r++;
	cout << "Az i memoriacime " << &i << " es a memoriaterulet tartalma " << i << endl;
	cout << "Az r memoriacime " << &r << " es a memoriaterulet tartalma " << r << endl;
	cout << "A  p memoriacime " << &p << " es a memoriaterulet tartalma " << p << endl;
	cout << "A  p altal hivatkozott memoriaterulet cime " << (&(*p)) << " es annak tartalma " << (*p) << endl;
	cout << "---------------------------------------------------" << endl;
	(*p)++;
	cout << "Az i memoriacime " << &i << " es a memoriaterulet tartalma " << i << endl;
	cout << "Az r memoriacime " << &r << " es a memoriaterulet tartalma " << r << endl;
	cout << "A  p memoriacime " << &p << " es a memoriaterulet tartalma " << p << endl;
	cout << "A  p altal hivatkozott memoriaterulet cime " << (&(*p)) << " es annak tartalma " << (*p) << endl;
	// FIGYELEM!!
	cout << "---------------------------------------------------" << endl;
	cout << "- MOST JON EGY SZOKASOS HIBA, ELRETTENTO PELDANAK -" << endl;
	cout << "---------------------------------------------------" << endl;
	p++; // Itt a memóriacímet változtatjuk meg
	cout << "Az i memoriacime " << &i << " es a memoriaterulet tartalma " << i << endl;
	cout << "Az r memoriacime " << &r << " es a memoriaterulet tartalma " << r << endl;
	cout << "A  p memoriacime " << &p << " es a memoriaterulet tartalma " << p << endl;
	cout << "A  p altal hivatkozott memoriaterulet cime " << (&(*p)) << " es annak tartalma " << (*p) << endl;
	cout << "Itt valami teljesen mas tortenik! A memoriateruletet valtoztattuk meg!" << endl;
	cout << "Nezzuk meg, hogy az uj terulet mogotti dolgokat meg lehet-e valtoztatni!" << endl;
	(*p)++;
	cout << "A  p memoriacime " << &p << " es a memoriaterulet tartalma " << p << endl;
	cout << "A  p altal hivatkozott memoriaterulet cime " << (&(*p)) << " es annak tartalma " << (*p) << endl;
	cout << "Ne feledjuk, c++-ban alapvetoen mindent lehet, kiveve par dolgot amit tilos!" << endl;




	return 0;
}
