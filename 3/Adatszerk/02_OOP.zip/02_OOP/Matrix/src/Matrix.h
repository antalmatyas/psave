#ifndef MATRIX_H
#define MATRIX_H

#include <ostream>

class Matrix {

};

#endif // MATRIX_H
