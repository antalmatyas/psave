#include <iostream>
#include "Matrix.h"

using namespace std;

int main() {
	cout << "Matrix" << endl;

	/*Matrix m1(3, 4);
	Matrix m2(4, 3);

	cout << "m1: " << endl << m1 << endl;
	cout << "m2: " << endl << m2 << endl;

	m1(2, 2) = 10;
	m1(1, 2) = 1;
	m1(2, 1) = 3;
	m1(2, 0) = 5;
	m1(0, 0) = 15;

	cout << endl << " par ertek valtoztatasa utan: ";

	cout << "m1: " << endl << m1 << endl;
	cout << "m2: " << endl << m2 << endl;

	m2 = m1;
	cout << endl << "m1-et ertekul adva m2-nek: " << endl;

	cout << "m1: " << endl << m1 << endl;
	cout << "m2: " << endl << m2 << endl;

	m1 += m2;
	cout << endl << "m1-hez hozza adva m2-t: " << endl;

	cout << "m1: " << endl << m1 << endl;
	cout << "m2: " << endl << m2 << endl;

	cout << endl << "m1==m2? " << endl;
	cout << (m1 == m2) << endl;

	cout << endl << "m1==m1? " << endl;
	cout << (m1 == m1) << endl;

	Matrix m3(m2);
	cout << endl << "m3 letrehozva m2-bol:" << endl;
	cout << m3;

	Matrix unitMatrix = Matrix::create_identity_matrix(3);
	cout << endl << "egyseg: " << endl << unitMatrix;*/

	return 0;
}
