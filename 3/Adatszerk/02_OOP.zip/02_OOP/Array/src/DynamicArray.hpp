#ifndef ARRAY_HPP_INCLUDED
#define ARRAY_HPP_INCLUDED

#include "AbstractArray.hpp"

class DynamicArray: public AbstractArray {

};

#endif // ARRAY_HPP_INCLUDED
