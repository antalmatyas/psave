#ifndef FIXEDARRAY_HPP_INCLUDED
#define FIXEDARRAY_HPP_INCLUDED

#include "AbstractArray.hpp"

class FixedArray: public AbstractArray {

};

#endif // FIXEDARRAY_HPP_INCLUDED
