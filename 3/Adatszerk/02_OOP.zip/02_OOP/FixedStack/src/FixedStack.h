#ifndef FIXEDSTACK_H_
#define FIXEDSTACK_H_

#include <iostream>

#endif /* FIXEDSTACK_H_ */
