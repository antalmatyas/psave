#ifndef CPUBLIC_H
#define CPUBLIC_H

#include "BPublic.h"

class CPublic: public BPublic {
public:
	CPublic();
	virtual ~CPublic();

	void hh();
protected:
private:
};

#endif // CPUBLIC_H
