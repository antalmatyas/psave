#ifndef CPROTECTED_H
#define CPROTECTED_H

#include "BProtected.h"

class CProtected: public BProtected {
public:
	CProtected();
	virtual ~CProtected();

	void hh();
protected:
private:
};

#endif // CPROTECTED_H
