#ifndef CPRIVATE_H
#define CPRIVATE_H

#include "BPrivate.h"

class CPrivate: public BPrivate {
public:
	CPrivate();
	virtual ~CPrivate();

	void hh();
protected:
private:
};

#endif // CPRIVATE_H
