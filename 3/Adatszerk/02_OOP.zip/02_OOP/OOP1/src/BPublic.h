#ifndef BPUBLIC_H
#define BPUBLIC_H

#include "A.h"

class BPublic: public A {
public:
	BPublic();
	virtual ~BPublic();

	void h();
protected:
private:
};

#endif // BPUBLIC_H
