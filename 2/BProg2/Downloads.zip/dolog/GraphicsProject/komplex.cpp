#include "komplex.hpp"

double komplex :: re()
{
    return rea;
}

double komplex :: im()
{
    return ima;
}


