#ifndef MANDELRAJZ_HPP_INCLUDED
#define MANDELRAJZ_HPP_INCLUDED

void mandelrajz(int XX, int YY, int MAX) ;

#endif // MANDELRAJZ_HPP_INCLUDED
