#include "Widget.hpp"
#include "Application.hpp"


Widget :: Widget(Application * _parent, int posx, int posy, int sizex, int sizey)
    : parent(_parent), x(posx), y(posy), size_x(sizex), size_y(sizey)
{
    _parent->add(this);
}

const bool Widget :: isOver(int px, int py)
{
    return (px >= _posx && px <= _posx + _sizex) && (py >= _posy && py <= _posy + _sizey);
}
