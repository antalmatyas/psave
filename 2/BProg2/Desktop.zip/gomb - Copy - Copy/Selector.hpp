#ifndef SELECTOR_HPP_INCLUDED
#define SELECTOR_HPP_INCLUDED

#include "Widget.hpp"
#include "Text.hpp"
#include "graphics.hpp"
#include <vector>

using namespace genv;
using namespace std;

class Selector : public Widget{
private:
    vector<string> elements;

    //Text* input;

    int selected_item = -1;
    int scroll = 0;
public:
    Selector(const int& xx, const int& yy, const int& s_x, const int& s_y) : Widget(xx, yy, s_x, s_y)
    {
        //input = new Text(x, y, size_x, gout.cascent()*2, this);
    }
    Selector(const int& xx, const int& yy, const int& s_x, const int& s_y, const vector<string>& e) : Widget(xx, yy, s_x, s_y)
    {
        elements = e;
        //input = new Text(x, y, size_x, gout.cascent()*2, this);
    }
    const void draw();
    void handle(event& ev);

    void add(const string& s);
    void del(const int& i);
    void del();
    const int isOver(event& ev);

    void setSelected();
    void setNotSelected();

    void save(const string& file);
};

#endif // SELECTOR_HPP_INCLUDED
