#include "graphics.hpp"
#include "Widget.hpp"
#include "Number.hpp"
#include "Selector.hpp"
#include "Button.hpp"

using namespace genv;
using namespace std;

class AddButton : public Button
{
public:
    AddButton(const int& xx, const int& yy, const int& s_x, const int& s_y, string t, Window * w) : Button(xx, yy, s_x, s_y, t, "", w){}
    void handle(event& ev);
};

class DelButton : public Button
{
public:
	DelButton(const int& xx, const int& yy, const int& s_x, const int& s_y, string t, Window * w) : Button(xx, yy, s_x, s_y, t, "", w) {}
	void handle(event& ev);
};

class Window{
public:
    vector<Widget*> elements;
    Selector* s;
    Text* t;
    AddButton* b;
    DelButton* db;
	Window()
	{
        s = new Selector(50,100,130,300);
		t = new Text(200,100,130,30);
		b = new AddButton(500,100,130,30, "Mehet", this);
		db = new DelButton(500,200,130,30, "T�rl�s", this);

		elements.push_back(s);
		elements.push_back(t);
		elements.push_back(b);
		elements.push_back(db);
	}
	~Window()
	{
        delete s;
        delete t;
        delete b;
        delete db;
	}
} w;

void AddButton::handle(event & ev)
{
    if(ev.button == btn_left)
    {
        parent->s->add(parent->t->valueOf());
        parent->t->setValue("");
    }
}
void DelButton::handle(event & ev)
{
    if(ev.button == btn_left)
    {
        parent->s->del();
    }
}

int main()
{
    gout.open(800,800);
    event ev;
    gin.timer(20);


    while(gin >> ev)
    {
        /// Kirajzol�s
        if(ev.type == ev_timer)
        {
            gout << color(0,0,0) << move_to(0,0) << box(800,800);

            for(int i = 0; i < w.elements.size(); i++)
            {
                w.elements[i]->draw();
            }
            gout << refresh;
        }

        /// Focus v�lt�s
        if(ev.type == ev_mouse && ev.button == btn_left)
        {
            bool notYet = true;
            for(int i = 0; i < w.elements.size(); i++)
            {
                if(w.elements[i]->isOver(ev) != -1 && notYet)
                {
                    w.elements[i]->setSelected();
                    notYet = false;
                }
                else
                {
                    w.elements[i]->setNotSelected();
                }
            }

        }

        /// Kezel�s
        for(int i = 0; i < w.elements.size(); i++)
        {
            if(w.elements[i]->isSelected()) w.elements[i]->handle(ev);
        }


    }

    return 0;
}
