#include "Widget.hpp"

Widget::Widget(int xx, int yy, int s_x, int s_y)
{
    x = xx;
    y = yy;
    size_x = s_x;
    size_y = s_y;

    selected = false;

    if(size_x < 50) size_x = 50;
    if(size_y < 20) size_y = 20;
}

void Widget::setSelected()
{
    selected = true;
}
void Widget::setNotSelected()
{
    selected = false;
}
const bool Widget::isSelected()
{
    return selected;
}
