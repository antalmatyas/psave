#ifndef TEXT_HPP_INCLUDED
#define TEXT_HPP_INCLUDED

#include "Widget.hpp"
#include "graphics.hpp"

using namespace genv;
using namespace std;

class Selector;

class Text : public Widget{
    string value;
    string hint;

    Selector* inside;
public:

    const void draw();
    void handle(event& ev);
    const int isOver(event& ev);

    void setValue(string s);

    Text(const int& xx, const int& yy, const int& s_x, const int& s_y) : Widget(xx, yy, s_x, s_y)
    {
        inside = NULL;
        value = "";
        hint = "Ide irhatsz";
    }
    Text(const int& xx, const int& yy, const int& s_x, const int& s_y, Selector* p) : Widget(xx, yy, s_x, s_y)
    {
        inside = p;
        value = "";
        hint = "Ide irhatsz";
    }

    string valueOf();
};

#endif // TEXT_HPP_INCLUDED
