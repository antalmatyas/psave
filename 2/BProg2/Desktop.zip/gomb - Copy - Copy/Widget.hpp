#ifndef WIDGET_HPP_INCLUDED
#define WIDGET_HPP_INCLUDED

#include "Widget.hpp"
#include "graphics.hpp"

using namespace genv;

class Widget{
protected:
    int x, y;
    unsigned int size_x, size_y;
    bool selected;

public:
    Widget(int xx, int yy, int s_x, int s_y);

    const virtual void draw() = 0;
    virtual void handle(event& ev) = 0;

    virtual const int isOver(event& ev) = 0;

    virtual void setSelected();
    virtual void setNotSelected();
    virtual const bool isSelected();
};


#endif // WIDGET_HPP_INCLUDED
