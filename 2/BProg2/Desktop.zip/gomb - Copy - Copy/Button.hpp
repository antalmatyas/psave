#ifndef BUTTON_HPP_INCLUDED
#define BUTTON_HPP_INCLUDED

#include "graphics.hpp"
#include "Widget.hpp"

using namespace std;

class Window;

class Button : public Widget{
    string value;
    string id;
public:
    Window * parent;
    Button(const int& xx, const int& yy, const int& s_x, const int& s_y, string t, string i, Window * w) : Widget(xx, yy, s_x, s_y){
        value = t;
        id = i;
        parent = w;
    }
    const void draw();
    const int isOver(event& ev);

    virtual void handle(event& ev) = 0;
};

#endif // BUTTON_HPP_INCLUDED
