#ifndef LABEL_H_INCLUDED
#define LABEL_H_INCLUDED

#include "graphics.hpp"
#include "widgets.hpp"
#include <string>

class Label : public Widget {
    std::string _text;
public:
    Label(int x, int y, int sx, int sy, std::string txt);
    virtual void draw() const ;
    virtual void handle(genv::event ev);
};


#endif // LABEL_H_INCLUDED
