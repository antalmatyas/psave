#include "textbox.hpp"
#include "graphics.hpp"
#include <string>
#include <iostream>
using namespace genv;

TextBox::TextBox(int x, int y, int sx, int sy)
    : Widget(x,y,sx,sy)
{}

void TextBox::draw() const
{
    int r, g, b;
    if(active)
    {
        r = 200;
        g = 200;
        b = 200;
    }
    else
    {
        r = 250;
        g = 250;
        b = 250;
    }
    gout << move_to(_x, _y) << color(r,g,b) << box(_size_x, _size_y);
    gout << move_to(_x+1, _y+1) << color(0,0,0) << box(_size_x-2, _size_y-2);
    gout << color(r,g,b) << move_to(_x, _y+(_size_y/2) + gout.cascent()/2) << text(content);

}

void TextBox::handle(event ev)
{
    if (ev.type == ev_key && ev.keycode >= 32 && ev.keycode <= 255 ) {
        writeChar((char)ev.keycode);
    }
    else if(ev.type == ev_key && ev.keycode == key_backspace)
    {
        deleteChar();
    }

}

void TextBox::writeChar(const char& c)
{
    if(gout.twidth(content+c) < _size_x) content = content + c;
}
void TextBox::deleteChar()
{
    if(content.size() > 0)  content.resize(content.length()-1);
}
