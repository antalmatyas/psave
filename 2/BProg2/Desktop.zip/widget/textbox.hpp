#ifndef TEXTBOX_HPP_INCLUDED
#define TEXTBOX_HPP_INCLUDED

#include "graphics.hpp"
#include "widgets.hpp"

class TextBox : public Widget {
protected:
    std::string content;
public:
    TextBox(int x, int y, int sx, int sy);
    virtual void draw() const ;
    virtual void handle(genv::event ev);

    void writeChar(const char& c);
    void deleteChar();
};



#endif // TEXTBOX_HPP_INCLUDED
