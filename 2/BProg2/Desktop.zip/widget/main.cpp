#include "graphics.hpp"
#include "widgets.hpp"
#include "examplecheckbox.hpp"
#include "label.h"
#include "textbox.hpp"
#include <vector>
#include <iostream>
using namespace std;
using namespace genv;

void event_loop(vector<Widget*>& widgets) {
    event ev;
    int focus = -1;
    while(gin >> ev ) {
        if (ev.type == ev_mouse && ev.button==btn_left) {
            for (size_t i=0;i<widgets.size();i++) {
                if (widgets[i]->is_selected(ev.pos_x, ev.pos_y)) {
                        if(focus != -1) widgets[focus]->set_inactive();
                        focus = i;
                        widgets[focus]->set_active();
                }
            }
        }
        if(ev.type == ev_key && ev.keycode == key_tab)
        {
            if(focus != -1) widgets[focus]->set_inactive();

            if(focus < widgets.size() - 1) focus++;
            else focus = 0;
            widgets[focus]->set_active();
        }
        if (focus!=-1) {
            widgets[focus]->handle(ev);
        }
        for (size_t i=0;i<widgets.size();i++) {
            widgets[i]->draw();
        }
        gout << refresh;
    }
}


int main()
{
    gout.open(400,400);
    vector<Widget*> w;
    ExampleCheckBox * b1 = new ExampleCheckBox(10,10,30,30);
    ExampleCheckBox * b2 = new ExampleCheckBox(10,50,30,30);
    Label * l1 = new Label(10,100,50,30, "szoveg");
    TextBox * tb1 = new TextBox(100,100,50,30);

    w.push_back(b1);
    w.push_back(b2);
    w.push_back(l1);
    w.push_back(tb1);
    event_loop(w);
    return 0;
}
