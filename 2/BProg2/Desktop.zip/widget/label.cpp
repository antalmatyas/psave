#include "label.h"
#include "graphics.hpp"
#include <string>
using namespace genv;

Label::Label(int x, int y, int sx, int sy, std::string txt)
    : Widget(x,y,sx,sy)
{
    _text = txt;
}

void Label::draw() const
{
    int r, g, b;
    if(active)
    {
        r = 200;
        g = 200;
        b = 200;
    }
    else
    {
        r = 250;
        g = 250;
        b = 250;
    }
    gout << color(r,g,b) << move_to(_x, _y+(_size_y/2) + gout.cascent()/2) << text(_text);
}

void Label::handle(event ev)
{

}

