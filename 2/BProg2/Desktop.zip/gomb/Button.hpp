#ifndef BUTTON_HPP_INCLUDED
#define BUTTON_HPP_INCLUDED

#include "graphics.hpp"
#include "Widget.hpp"

using namespace std;

class Window;

class Button : public Widget{
    string value;
    string id;
public:
    Button(const int& xx, const int& yy, const int& s_x, const int& s_y, string t, string i, Window * w) : Widget(xx, yy, s_x, s_y, w){
        value = t;
        id = i;
    }
    const void draw();
    const int isOver(event& ev);

    virtual void handle(event& ev) = 0;
};

#endif // BUTTON_HPP_INCLUDED
