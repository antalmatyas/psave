#include <vector>
#include <fstream>

#include "Widget.hpp"
#include "Selector.hpp"
#include "graphics.hpp"
using namespace genv;
using namespace std;

const void Selector::draw()
{
    int c = 105 + ((int)selected * 150);
    int canContain = size_y / gout.cascent() / 2;
    int boxHeight = gout.cascent() * 2;
    int elementQty = elements.size();

    // Keret
    gout << color(c, c, c)
         << move_to(x, y)
         << box(size_x, size_y);
    gout << color(20, 20, 20)
         << move_to(x + 1,y + 1)
         << box(size_x - 2, size_y - 2);

    // Input
    //input->draw();

    // Vektor
    for(size_t i = 0; i < elements.size() && i < canContain; i++)
    {
        int shifted = i + scroll;
        if(selected_item == shifted)
        {
            gout << color(c,c,c)
             << move_to(x, y + ((i) * boxHeight))
             << box(size_x, boxHeight)
             << genv::move(-size_x + 5, -5)
             << color(20,20,20) << text(elements[shifted]);
        }
        else
        {
           gout << color(c,c,c)
             << move_to(x, y + ((i + 1) * boxHeight))
             << line(size_x, 0)
             << genv::move(-size_x + 5, -5)
             << text(elements[shifted]);
        }

    }
    // G�rg�s�v -- keret
    gout << move_to(x+size_x, y)
         << color(c,c,c)
         << box(-20, size_y);
    gout << move_to(x+size_x -1, y + 1)
         << color(20,20,20)
         << box(-20 + 2, size_y - 2);
    // G�rg�s�v -- pocak
    if(elementQty > 0)
    gout << move_to(x + size_x -2, y + 2 + (size_y-4) * scroll / (elementQty / (double)canContain) / 10 )
         << color(c,c,c)
         << box(-20 + 4, (size_y - 4) * ((canContain < elementQty) ? (double)canContain / elementQty : 1));

}

void Selector::handle(event& ev)
{
    int canContain = (size_y / gout.cascent() / 2 - 1);

    //if(ev.type == ev_key) input->handle(ev);  /// Bemenet kezel�se

    if(ev.type == ev_mouse && ev.button == btn_left)
    {
        int item = isOver(ev);
        if(item != -1 && item < elements.size()) selected_item = item + scroll;
    }
    else if(ev.type == ev_mouse && ev.button == btn_wheeldown && elements.size() > canContain && scroll < (elements.size() - canContain))
    {
        scroll++;
    }
    else if(ev.type == ev_mouse && ev.button == btn_wheelup && scroll > 0)
    {
        scroll--;
    }

    if (ev.type == ev_key && ev.keycode == key_up && selected_item != -1 && selected_item != 0)
    {
        selected_item--;
        if(selected_item < scroll) scroll--;
    }
    else if(ev.type == ev_key && ev.keycode == key_down && selected_item != -1 && selected_item != elements.size() - 1)
    {
        selected_item++;
        if(selected_item > scroll + canContain - 1) scroll++;
    }
    else if(ev.type == ev_key && ev.keycode == key_pgup)
    {
        selected_item = 0;
        scroll = 0;
    }
    else if(ev.type == ev_key && ev.keycode == key_pgdn)
    {
        selected_item = elements.size() - 1;
        scroll = ((elements.size() > canContain) ? (elements.size() - canContain) : 0);
    }

}

const int Selector::isOver(event& ev)
{
    if(ev.pos_x >= x && ev.pos_x <= x + size_x &&
    ev.pos_y >= y && ev.pos_y <= y + size_y)
    {
        if(ev.pos_x > x + size_x - 20) return -3;   /// TODO: esetleg kattint�ssal is lehet ir�ny�tani a g�rg�t
        return ( int(ev.pos_y - y) / gout.cascent() / 2);   /// Az input miatti eltol�s miatt ilyen cs�nya
        /// (-2) azt jelenti, hogy nem (-1) teh�t benne van, de nem is indexszel t�r vissza
    }
    return -1;
}

void Selector::add(const string& s)
{
    elements.push_back(s);
}

void Selector::setSelected()
{
    selected = true;
    //input->setSelected();
}
void Selector::setNotSelected()
{
    selected = false;
    //input->setNotSelected();
}

void Selector::save(const string& file)
{
    ofstream s(file.c_str());
    s << ((selected_item == -1) ? "" : elements[selected_item]);
}

void Selector::del(const int& i)
{
    if(elements.size() > 0)
    elements.erase(elements.begin() + i);
}
void Selector::del()
{
    if(selected_item != -1 && elements.size() > 0) elements.erase(elements.begin() + selected_item);
}
