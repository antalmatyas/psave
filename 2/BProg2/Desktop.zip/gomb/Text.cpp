#include "graphics.hpp"

#include "Widget.hpp"
#include "Selector.hpp"
#include "Text.hpp"

using namespace genv;
using namespace std;

const void Text::draw()
{
    int c = 105 + ((int)selected * 150);
    gout << move_to(x, y)
         << color(c,c,c)
         << box(size_x, size_y);
    gout << color(20,20,20)
         << move_to(x + 1, y + 1)
         << box(size_x - 2, size_y - 2);

    gout << move_to(x + 2, y + gout.cascent() + 5)
         << color(c,c,c)
         << ((value.length() > 0) ? text(value) : text(hint));
}
void Text::handle(event& ev)
{
    if(ev.type == ev_key && ev.keycode >= 32 && ev.keycode <= 126)
    {
        value = value + (char)ev.keycode;

        if(gout.twidth(value) > size_x - 25)
        {
            value.resize(value.length() - 1);
        }

    }
    if(ev.type == ev_key && ev.keycode == key_backspace && value.length() > 0)
    {
        value.resize(value.length() - 1);
    }
    if(ev.type == ev_key && ev.keycode == key_enter && inside && value.length() > 0)
    {
        inside->add(value);
        value.clear();
    }
}
const int Text::isOver(event& ev)
{
    if(ev.pos_x > x && ev.pos_x < x + size_x && ev.pos_y > y && ev.pos_y < y + size_y )
    {
        return 1;
    }
    return -1;
}

string Text::valueOf()
{
    return value;
}

void Text::setValue(string s)
{
    value = s;
}
