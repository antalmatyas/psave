#include "graphics.hpp"
#include "Window.hpp"
#include "Widget.hpp"
#include "Number.hpp"
#include "Selector.hpp"
#include "Button.hpp"
#include "cstdlib"
#include "iostream"
#include "sstream"

using namespace genv;
using namespace std;



int main()
{

    gout.open(800,800);
    event ev;
    gin.timer(20);

    Window w;

    while(gin >> ev)
    {
        /// Kirajzol�s
        if(ev.type == ev_timer)
        {
            gout << color(0,0,0) << move_to(0,0) << box(800,800);

            for(int i = 0; i < w.elements.size(); i++)
            {
                w.elements[i]->draw();
            }
            gout << refresh;
        }

        /// Focus v�lt�s
        if(ev.type == ev_mouse && ev.button == btn_left)
        {
            bool notYet = true;
            for(int i = 0; i < w.elements.size(); i++)
            {
                if(w.elements[i]->isOver(ev) != -1 && notYet)
                {
                    w.elements[i]->setSelected();
                    notYet = false;
                }
                else
                {
                    w.elements[i]->setNotSelected();
                }
            }

        }

        /// Kezel�s
        for(int i = 0; i < w.elements.size(); i++)
        {
            if(w.elements[i]->isSelected()) w.elements[i]->handle(ev);
        }


    }

    return 0;
}
