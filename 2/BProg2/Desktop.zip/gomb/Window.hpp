#ifndef WINDOW_HPP_INCLUDED
#define WINDOW_HPP_INCLUDED

#include "Widget.hpp"
#include "Number.hpp"
#include "Selector.hpp"
#include "Button.hpp"

class Window{
public:
    vector<Widget*> elements;


};

#endif // WINDOW_HPP_INCLUDED
