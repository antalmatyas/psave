#ifndef NUMBER_HPP_INCLUDED
#define NUMBER_HPP_INCLUDED

#include "Widget.hpp"
#include "graphics.hpp"

using namespace genv;
using namespace std;

class Window;

class Number : public Widget{
private:
    int value;
    int minimum, maximum;
    int step;
public:
    Number(const int& xx, const int& yy, const int& s_x, const int& s_y, int v, Window * w, const int& mi = 0, const int& ma = 100, const int& st = 1) : Widget(xx, yy, s_x, s_y, w)
    {
        value = v;
        minimum = mi;
        maximum = ma;
        step = st;
    }
    const void draw();
    void handle(event& ev);

    const int isOver(event& ev);
    const string stringValueOf();

    void save(const string& file);
};

#endif // NUMBER_HPP_INCLUDED
