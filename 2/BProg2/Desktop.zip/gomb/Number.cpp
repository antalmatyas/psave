#include <sstream>
#include <fstream>

#include "Widget.hpp"
#include "Number.hpp"
#include "graphics.hpp"

using namespace genv;
using namespace std;

const void Number::draw()
{
    int c = 105 + ((int)selected * 150);
    // Doboz benne a sz�mmal
    gout << color(c, c, c)
         << move_to(x, y)
         << box(size_x, size_y);
    gout << color(20, 20, 20)
         << move_to(x + 1,y + 1)
         << box(size_x - 2, size_y - 2);

    gout << move_to(x + 2, y + gout.cascent() + 2)
         << color(c, c, c)
         << text(stringValueOf());

    // Fel le gombok
    // Doboz
    gout << move_to(x + size_x - 20, y)
         << box(20, size_y);
    // Elv�laszt�vonal
    gout << color(20, 20, 20)
         << move_to(x+size_x - 20, y+size_y / 2)
         << line(20,0);
    // N�vel� nyilacska
    gout << genv::move(-5, -2)
         << line_to(x + size_x - 20 + 5, y + (size_y/2) - 2 -1)
         << line_to(x + size_x - 10, y + 1)
         << line_to(x + size_x -5, y + (size_y/2) - 2 - 1);
    // Cs�kkent� nyilacska
    gout << genv::move(0, 5)
         << line_to(x + size_x - 20 + 5, y + (size_y/2) + 2)
         << line_to(x + size_x - 10, y + size_y - 1 - 1)
         << line_to(x + size_x -5, y + (size_y/2) + 2 + 1);
}
void Number::handle(event& ev)
{
    if      (ev.type == ev_key && ev.keycode == key_up)     value += step;
    else if (ev.type == ev_key && ev.keycode == key_down)   value -= step;
    else if (ev.type == ev_key && ev.keycode == key_pgdn)   value -= step * 10;
    else if (ev.type == ev_key && ev.keycode == key_pgup)   value += step * 10;

    if      (ev.type == ev_mouse && ev.button == btn_left && isOver(ev) == 1) value += step;
    else if (ev.type == ev_mouse && ev.button == btn_left && isOver(ev) == 2) value -= step;

    if      (value > maximum) value = maximum;
    else if (value < minimum) value = minimum;
}

const int Number::isOver(event& ev)
{
    if(ev.pos_x >= x && ev.pos_x <= x + size_x &&
    ev.pos_y >= y && ev.pos_y <= y + size_y)
    {
        /// nyilacskak
        if(ev.pos_x >= x + size_x - 20 && ev.pos_x <= x + size_x &&
        ev.pos_y >= y               && ev.pos_y <= y + size_y)
        {
            if(ev.pos_y < y + (size_y/2)) return 1; /// felfele
            if(ev.pos_y > y + (size_y/2)) return 2; /// lefel�
        }
        return 0;   /// benne van, de nem nyilacska
    }
    return -1;  /// nincs benne

}

const string Number::stringValueOf()
{
    stringstream s;
    string v;
    s << value;
    s >> v;
    return v;
}

void Number::save(const string& file)
{
    ofstream s(file.c_str());
    s << value;
}
