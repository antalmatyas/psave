function abra=gyak7_f72_megoldas(x_min,x_max,y_min,y_max,Az,El)
[X,Y]=meshgrid(x_min:.02:x_max,y_min:.02:y_max);
r=sqrt(X.^2+Y.^2);
Z=(0.5.*(sin(r)).*(cos(r)));
abra = figure;
surf(X,Y,Z);
hold on
c=contour(X,Y,Z);
clabel(c);
colorbar;
colormap jet;
title '0.5sin(r)cos(r)';
xlabel 'x �rt�kek'
ylabel 'y �rt�kek'
zlabel 'z �rt�kek' 
view(Az,El)
end