function abra=gyak7_f71_megoldas(x_min,x_max,y_min,y_max)
[X,Y]=meshgrid(x_min:.25:x_max,y_min:.25:y_max);
Z=(sin(X).*(exp(-sin(X)-Y.^2)));
abra = figure;
surf(X,Y,Z)
colormap jet
xlabel('X �rt�kek')
ylabel('Y �rt�kek')
zlabel('Z �rt�kek')
title('Fel�let')
colorbar;
end