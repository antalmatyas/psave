x_min=-10; x_max= 5;y_min=-3;y_max=3;
abra1=gyak7_f71_megoldas(x_min,x_max,y_min,y_max);

x_min=-1; x_max= 1;y_min=-1;y_max=1;Az=20;El=20;
abra2=gyak7_f72_megoldas(x_min,x_max,y_min,y_max,Az,El);