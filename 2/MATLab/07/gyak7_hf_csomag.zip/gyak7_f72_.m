function abra=gyak7_f72_(x_min,x_max,y_min,y_max,Az,El)

%% �br�zol�s
abra = figure;

end