function abra=gyak7_f71_(x_min,x_max,y_min,y_max)

%% �br�zol�s
abra = figure;

end