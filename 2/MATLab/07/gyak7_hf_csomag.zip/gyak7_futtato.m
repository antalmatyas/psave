%% Futtató program a 7. házi feladataihoz
%% 7.1
% Példa értékek
x_min=-10; x_max= 5;y_min=-3;y_max=3;
% Írd át a fv. nevét úgy, hogy a neptun kódod legyen a végén
abra1=gyak7_f71_(x_min,x_max,y_min,y_max);
%% 7.2
% Példa értékek
x_min=-1; x_max= 1;y_min=-1;y_max=1;Az=20;El=20;
% Írd át a fv. nevét úgy, hogy a neptun kódod legyen a végén
abra2=gyak7_f72_(x_min,x_max,y_min,y_max,Az,El);