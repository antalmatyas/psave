%% 1. p�lda - pontfelh�

Pontfelho = rand(500,3);
figure
plot3(Pontfelho(:,1),Pontfelho(:,2),Pontfelho(:,3), 'k.')
title('Pontfelho 3D-ben')
xlabel('x koordinata')
ylabel('y koordinata')
zlabel('z koordinata')
xlim([-1 2]);ylim([-1 2]); zlim([-1 2])
grid on

%% 2. p�lda - fel�let �br�zol�sa
% a t�rh�l� l�trehoz�sa
[X,Y] = meshgrid(-2:0.1:2);
% a f�ggv�ny �rt�keinek
% kisz�m�t�sa
Z = X.*exp(-X.^2-Y.^2);

% kirajzol�s
figure;
surf(X,Y,Z);

figure;
mesh(X,Y,Z);

%% 3.1 p�lda - szintvonal
[X Y] = meshgrid (-3:0.1:3, -2:0.1:2);
figure
Z = peaks(X,Y);
% szintvonal-ertek szinkodhoz rendelesehez kell (clabel)
C = contour(X,Y,Z);
colorbar
% itt rendeljuk hozza
clabel(C)
title('Peaks szintvonalai')
xlabel('x koordinata')
ylabel('y koordinata')

%% 3.2 p�lda - fel�let + szintvonal
figure
surfc(X,Y,Z);
title('Peaks szintvonalai')
xlabel('x koordinata')
ylabel('y koordinata')
colorbar

%% 3.3 p�lda - view haszn�lata
El = 30;
for Az = 0:180
    view(Az,El)
    pause(0.1)
end

%% 4. p�lda - vektormez�k
[x,y] = meshgrid(-1.1:.2:1.1); % a jol ismert terhalonk
figure % uj abra

subplot(221); % sok kis abrank lesz ugyebar
quiver(x,y); % a kis nyilacskak az adott pontban levo "aramlas" sebesseget jelzik
axis equal; % szepre allitjuk a tengelyeket
title('quiver(x,y)');

subplot(222); % kovetkezo abrara lepunk
quiver(x,x); % a sebessegnek iranya es nagysaga is van, ezert jok nekunk a nyilak
axis equal; % folytatas...
title('quiver(x,x)');

subplot(223); % folytatas...
quiver(-y,x); % folytatas...
axis equal; % folytatas...
title('quiver(-y,x)');

subplot(224); % folytatas...
quiver(y,x); % folytatas...
axis equal; % folytatas...
title('quiver(y,x)');

%% quiver3
x = -3:0.5:3;
y = -3:0.5:3;
[X,Y] = meshgrid(x, y);
Z = Y.^2 - X.^2;
[U,V,W] = surfnorm(Z);
figure
quiver3(Z,U,V,W);

%% gyakfeladatok megoldassal: pelda 1

[X, Y] = meshgrid(-15:0.5:15);
% k�ralakban �br�zolunk
R = sqrt(X.^2+Y.^2);
Z = sin(R)./R;
% kirajzol�s
figure
surfc(X,Y,Z)
xlabel('x koordinata')
ylabel('y koordinata')
zlabel('z koordinata')

%% gyakfeladatok megoldassal: pelda 2
% a fel�let pontjainak l�trehoz�sa
[X,Y,Z] = peaks(20);
% gradiens kisz�m�t�sa
[PX,PY] = gradient(Z);
% kirajzol�s
figure
subplot(121)
hold on
% a gradienst �br�zol� vektormez�
quiver(X,Y,PX,PY);
% ugyanitt a szintvonalak
contour(X, Y, Z);
axis([min(min(X)) max(max(X)) min(min(Y)) max(max(Y))]);
view([15 15]);
subplot(122);
% fel�let + szintvonalak
surfc(X, Y, Z);
axis([min(min(X)) max(max(X)) min(min(Y)) max(max(Y))]);
view([15 15]);

%% gyakfeladatok megoldassal: pelda 3
[X,Y] = meshgrid(-5:0.1:5);
Z = sin(X).*cos(Y);

figure;
surfc(X,Y,Z);

axis square
title('Fel�let');
xlabel('x �rt�kek');
ylabel('y �rt�kek');
zlabel('z �rt�kek');

%% gyakfeladatok megoldassal: pelda 4
% a t�rh�l� pontjainak l�trehoz�sa
[X,Y] = meshgrid(0:0.1:3,-1:0.1:1);
% a fel�let pontjainak kisz�m�t�sa
Z = sin(X)./cos(Y);
% norm�lvektorok kisz�m�t�sa
[U,V,W] =surfnorm(X,Y,Z);

% �br�zol�s
figure;
% norm�lvektorok t�rben
quiver3(X,Y,Z,U,V,W);
hold on
% fel�let
surf(X,Y,Z);
% n�zet
view(-35,45)
axis square
hold off
