%% Els� feladat, 20 pont
% Pr�ba �rt�kek - ne v�ltoztassa!
nap = [1 1 2 2 2 3 5 6 6 7 7 7]; 
hely = [0 2 5 3 2 8 6 4 2 0 1 2]; 
meres = [0.2, 3.1, 1.1, 2.3, 4.4, 0.2, 5.2, 1.0, 0.4, 5.2, 1.0, 0.4];
a = randi([0,6]);
b = randi([0,3]);
c = randi([1,17]);
% A f�ggv�ny nev�t �rja �t a saj�t f�ggv�ny�nek a nev�re! zh1_f11_[NEPTUN]
[d,e,f,g] = zh1_f11_sol(nap, hely, meres, a, b, c);
%% M�sodik feladat, 30 pont
% Pr�ba �rt�kek - ne v�ltoztassa!
also = randi([20,40])/100;
felso = randi([70,90])/100;
% A f�ggv�ny nev�t �rja �t a saj�t f�ggv�ny�nek a nev�re! zh1_f12_[NEPTUN]
[abra1, csatornak, valasztott_atlag, nullazott, kul, vektor, P1, kiertekelt_polinom ] = zh1_f12_sol(also, felso);
%% Harmadik feladat, 50 pont
% Pr�ba �rt�kek - ne v�ltoztassa!
meresek = sort(randi([0 180],[2,1]));
lepesSzam = randi([60 120]);
% A f�ggv�ny nev�t �rja �t a saj�t f�ggv�ny�nek a nev�re! zh1_f13_[NEPTUN]
[abra2, maxSebesseg, megtettUt]=zh1_f13_sol(meresek(1),meresek(2),lepesSzam);