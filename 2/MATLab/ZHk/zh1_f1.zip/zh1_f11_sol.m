function [d,e,f,g] = zh1_f11_sol(nap, hely, meres, a, b, c)
d=sum(meres);
e=sum(meres(hely==a));
f=mean(meres(nap==b));
cumulative = meres;
for i = 2:length(meres)
    cumulative(i)=cumulative(i-1)+cumulative(i);
end
g=nap(find(cumulative>c,1));
end