function [abra, csatornak, valasztott_atlag, nullazott, kul, vektor, P1, kiertekelt_polinom ] = zh1_f32_sol(in1, in2)

% in1 = 0.1;
% in2 = 0.9;

kep=rand(128,128,3);
csatornak = kep(:,:,[1 3]);
if mean(mean(csatornak(:,:,1).^2)) > mean(mean(csatornak(:,:,2).^2))
    valasztott_atlag = csatornak(:,:,1);
else
    valasztott_atlag = csatornak(:,:,2);
end

valasztott_atlag(valasztott_atlag > in2 | valasztott_atlag < in1) = 0;
nullazott = valasztott_atlag;

kul = min(min(nullazott)) - abs(sum(nullazott(57,:)));
vektor = linspace(in1,in2,100);
P1 = nullazott(end-4:end,88);
kiertekelt_polinom = polyval(P1,vektor);

abra = figure;
plot(vektor,kiertekelt_polinom, 'b-')
hold on
plot([(vektor(1) + vektor(end))/2 (vektor(1) + vektor(end))/2],[0 2], 'r--')
title('polinom abra')
xlabel('idoegyseg')
ylabel('P1(t)')
legend('kek','piros')


end

