function [abra, maxSebesseg, megtettUt]=zh1_f13_sol(meres1,meres2,lepesSzam)
t = linspace(meres1,meres2,lepesSzam);
v = ones(size(t));
v(t>0 & t<100) = 0.8*t(t>0 & t<100)+10*sin(0.4*t(t>0 & t<100));
v(t>=100 & t<150) = 88.5+0.02*t(t>=100 & t<150)+cos(0.6*t(t>=100 & t<150));
v(t>=150) = 91.5*exp(-t(t>=150));
[maxSebesseg, maxHely] = max(v);
maxIdopont = t(maxHely);
megtettUt = trapz(t,v);
abra = figure;
plot(t,v,'b.-');
hold on;
plot(maxIdopont,maxSebesseg,'rd','Markersize',8,'MarkerFaceColor','c');
xlim([t(1),t(end)]);
ylim([min(v)-1 max(v)+1])
xlabel('Id� [s]');
ylabel('Sebess�g [m/s]');
grid on;
title(sprintf('Aut� szimul�ci�: m�r�s kezdete %ds, m�r�s v�ge %ds,\n maxim�lis sebess�g %4.2fm/s, megtett �t %4.2fm',meres1,meres2,maxSebesseg,megtettUt));
end