function [szurt_tabla, racs_X, racs_Y, abra] = zh2_f22_sol()
adatok=readtable('UAVflight1.csv','ReadVariableNames',true);
joindexek = adatok.Lat >=47 & adatok.Lat <=48 & adatok.Lng >=19 & adatok.Lng<=20 & adatok.Alt>=140 & adatok.Alt<=200;
szurt_tabla = adatok(joindexek,:);
szurt_tabla.Alt(szurt_tabla.Alt<145)=145;
[X,Y] =  meshgrid(linspace(min(szurt_tabla.Lat), max(szurt_tabla.Lat), 200),linspace(min(szurt_tabla.Lng), max(szurt_tabla.Lng), 200));
racs_X = X;
racs_Y = Y;
domborzat=readtable('domborzat2.csv');
Z=table2array(domborzat);
abra = figure;
%Abraval kapcsolatos parancsok ez utan kovetkezzenek
surf(X,Y,Z);
hold on
pirosak = szurt_tabla.HDop>=1;
kekek = szurt_tabla.HDop<1 & szurt_tabla.HDop>.85;
zoldek = szurt_tabla.HDop<=.85;
plot3(szurt_tabla.Lat(pirosak),szurt_tabla.Lng(pirosak),szurt_tabla.Alt(pirosak),'.r');
plot3(szurt_tabla.Lat(kekek),szurt_tabla.Lng(kekek),szurt_tabla.Alt(kekek),'.b');
plot3(szurt_tabla.Lat(zoldek),szurt_tabla.Lng(zoldek),szurt_tabla.Alt(zoldek),'.g');
title('rep�ltem')
xlabel('Lat')
ylabel('Lon')
zlabel('Alt')
xlim([min(szurt_tabla.Lat), max(szurt_tabla.Lat)])
ylim([min(szurt_tabla.Lng), max(szurt_tabla.Lng)])
zlim([min(min(Z)), max(szurt_tabla.Alt)])
print('uav','-dpng','-r300')
end