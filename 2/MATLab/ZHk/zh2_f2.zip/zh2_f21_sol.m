function [abra, t, y, y_pont, M, dy, kulonbseg] = zh2_f21_sol(a,b,c,d,e,f)

% teljesen ugyanilyen tipusu diffegyenletek, amelyekrol ez a feladat lett mintazva (csak a szamok masok, az elv egy az egyben ugyanaz), a kovetkezok:
% 1. feladat    https://wiki.itk.ppke.hu/twiki/pub/PPKE/Matlab/10_lab_matlab_2017_1517.pdf
% 4. pelda MAGYARAZATTAL      https://wiki.itk.ppke.hu/twiki/pub/PPKE/Matlab/06_lab_matlab_2017.pdf
% 2. feladat https://wiki.itk.ppke.hu/twiki/pub/PPKE/Matlab/11_lab_matlab_2017.pdf
% (+ 6.5 feladat a van der pol osszcillatoros a feladatgyujtemenybol, amely
% szinten mutatja az atirast!)
% ode45 help 2. pelda "Solve nonstiff equation"

% Vegeredmenyben tehat ez a fajta diffegyenlet tipus (masodrendu) 3(!)
% kulonbozo oran is elokerult.

% ay''+by'+dy = sin(c), y(0) = -1, y'(0) = 0
% defining so that y' = x and y'' = x' = (sin(c) - dy - bx)/a

tspan = [e f];
init_cond = [-1 0];

odefun = @(t,x) [x(2); (sin(c)-d*x(1)-b*x(2))/a];

[t, x] = ode45(odefun, tspan, init_cond);

y = x(:,1);
y_pont = x(:,2);

abra = figure;
subplot 121

plot(t,y,'k--')
hold on
plot(t,y_pont,'r-')

xlabel('ido')
ylabel('y(t)')
title('idotartomanybeli valtozasok')

M = reshape(y_pont(1:100),[10 10]);
M(M > mean(M(:))) = 0;
%M(M>mean(mean(M)) = 0; ugyanazt adja

dy = diff(y)./diff(t); %1-gyel r�vid�l a hossza, plotn�l fontos

kulonbseg = sqrt(sum((dy-y_pont(1:end-1)).^2)); % sum n�lk�l is elfogadtuk 

plot(t(1:end-1),diff(y)./diff(t),'g.') %diff miatt t-b�l egy elemmel kevesebb kell
legend('x', 'dx/dt', 'dx/dt manualis')


subplot 122
plot(y,y_pont,'b')
xlabel('ido')
ylabel('y(t)')
title('allapotter')


end




