function [abra,javitottIdo,javitottJel,terulet]=zh1_f34_sol(t,jel,pontokSzama)
javitottIdo = linspace(t(1),t(end),pontokSzama);
P = polyfit(t,jel,7);
fv = @(x) polyval(P,x);
javitottJel = fv(javitottIdo);
terulet = integral(fv,t(1),t(end));
abra = figure;
plot(t,jel,'ko');
hold on;
plot(javitottIdo,javitottJel,'b.-')
title(sprintf('Szinuszos jel jav�t�sa\n g�rbe alatti ter�let: %4.2f',terulet));
xlabel('Id� [s]');
ylabel('Amplit�d�');
legend('Eredeti jel','Jav�tott jel');
end