function aramok=zh1_f33_sol(R1,R2,R3,R4,R5,V1,V2)
A=[1 -1 -1;R1+R4 R3 0;0 -R3 R2+R5];
b=[0;-V1;-V2];
aramok=A\b;
end