
function [abra, zold_csatorna, M_log, ennyi_nagyobb, felulirt, min_sor, max_gyok, kulonbseg, polinom, t_idovektor, kiertekelt] = zh1_f32_sol(in1, in2)

% in1 = 0.3;
% in2 = 0.8;

load kep

zold_csatorna = kep(:,:,2);
M_log = zold_csatorna > in1;
ennyi_nagyobb = sum(sum(M_log));
zold_csatorna(zold_csatorna>in2) = in2;
felulirt = zold_csatorna;
min_sor = min(mean(felulirt,2));
max_gyok = sqrt(max(max(felulirt)));
kulonbseg = exp(abs(min_sor - max_gyok));

polinom = felulirt(76,end-3:end);
t_idovektor = -5:0.01:5;
kiertekelt = polyval(polinom,t_idovektor);

abra = figure;
plot(t_idovektor,kiertekelt, 'k')
title('Polinom fgv')
xlabel('idoegyseg')
ylabel('p(t)')
ylim([-15 30])


end