%% Els� feladat, 20 pont
% Pr�ba �rt�kek - ne v�ltoztassa!
a = randi([-220,203]);
b = randi([1253,11000]);
c = randi([11,294]);
% T�ltse be a mat f�jlt!
load varosok
% A f�ggv�ny nev�t �rja �t a saj�t f�ggv�ny�nek a nev�re! zh1_f21_[NEPTUN]
[d,e,f,g,h] = zh1_f31_sol(pozicioX, pozicioY, lakossag, a, b, c);
%% M�sodik feladat, 30 pont
% Pr�ba �rt�kek - ne v�ltoztassa!
also = randi([20,40])/100;
felso = randi([70,90])/100;
% A f�ggv�ny nev�t �rja �t a saj�t f�ggv�ny�nek a nev�re! zh1_f32_[NEPTUN]
[abra1, zold_csatorna, M_log, ennyi_nagyobb, felulirt, min_sor, max_gyok, kulonbseg, polinom, t_idovektor, kiertekelt] = zh1_f32_sol(also, felso);
%% Harmadik feladat, 20 pont
% Pr�ba �rt�kek - ne v�ltoztassa!
R = sort(randi([50 200],[5,1]));
V = randi([5 24],[2,1]);
% A f�ggv�ny nev�t �rja �t a saj�t f�ggv�ny�nek a nev�re! zh1_f33_[NEPTUN]
aramok=zh1_f33_sol(R(1),R(2),R(3),R(4),R(5),V(1),V(2));
%% Negyedik feladat, 30 pont
% Pr�ba �rt�kek - ne v�ltoztassa!
t = [0 1.39626340159546 2.79252680319093 4.18879020478639 5.58505360638185 6.98131700797732 8.37758040957278 9.77384381116825 11.1701072127637 12.5663706143592];
jel = sin(t);
pontokSzama = randi([100 300]);
% A f�ggv�ny nev�t �rja �t a saj�t f�ggv�ny�nek a nev�re! zh1_f34_[NEPTUN]
[abra2,javitottIdo,javitottJel]=zh1_f34_I0KAYJ(t,jel,pontokSzama);