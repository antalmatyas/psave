function [d,e,f,g,h] = zh1_f31_sol(pozicioX, pozicioY, lakossag, a, b, c)
d=sum(lakossag);
e=mean(lakossag(pozicioY>a));
f=pozicioX(lakossag<b);
g=pozicioY(lakossag<b);
dist = sqrt(pozicioX.^2+pozicioY.^2);
h=sum(lakossag(dist<c));
end