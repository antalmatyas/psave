function [d,e,f,g] = zh1_f21_sol(magassag, testsuly, a, b, c)
d=testsuly./(magassag.^2);
e=mean(testsuly(magassag<a));
f=min(magassag(d>b));
g=sum(d>=(c-1) & d<=(c+1));
end