
function [piros_csatorna, szamlalo, atlag_piros, atlagertek_felulirt, osz_max_min, sor_min, eredmeny_szinusz, kimentett, flag] = zh1_f22_sol(in1, in2)


kep=rand(128,128,3);

piros_csatorna = kep(:,:,1);
szamlalo = sum(sum(piros_csatorna > in1 & piros_csatorna <= in2));
atlag_piros = mean(mean(piros_csatorna));
piros_csatorna(piros_csatorna > atlag_piros) = atlag_piros;
atlagertek_felulirt = piros_csatorna;
osz_max_min = min(max(piros_csatorna,[],1));
sor_min = sind(min(sum(piros_csatorna,2)));
eredmeny_szinusz = osz_max_min + sor_min;
kimentett = atlagertek_felulirt(35,end-4:end);

if eredmeny_szinusz < sum(kimentett)
    flag = 1;
else
    flag = 0;
end

end
