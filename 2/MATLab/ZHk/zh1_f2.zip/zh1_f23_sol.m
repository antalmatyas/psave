function [abra, maxSebesseg, megtettUt]=zh1_f23_sol(meres1,meres2)
load hajo
rovidT=t(t>=meres1 & t<=meres2);
lepesek = sqrt(diff(x(t>=meres1 & t<=meres2)).^2+diff(y(t>=meres1 & t<=meres2)).^2);
v = lepesek./diff(rovidT)/1000;
[maxSebesseg, maxHely] = max(v);
maxIdopont = rovidT(maxHely);
megtettUt = sum(lepesek);
abra = figure;
subplot(2,1,1);
plot(rovidT(1:end-1),v,'b.-');
hold on;
plot(maxIdopont,maxSebesseg,'pk','Markersize',10,'MarkerFaceColor','c');
xlim([rovidT(1),rovidT(end-1)]);
ylim([min(v)-0.1 max(v)+0.1])
xlabel('Id� [h]');
ylabel('Sebess�g [km/h]');
grid on;
title(sprintf('Haj� szimul�ci�: m�r�s kezdete %dh, m�r�s v�ge %dh,\n maxim�lis sebess�g %4.2fkm/h, megtett �t %4.2fm',meres1,meres2,maxSebesseg,megtettUt));
subplot(2,1,2);
plot(x(t>=meres1 & t<=meres2),y(t>=meres1 & t<=meres2),'b.-');
xlabel('x koordin�ta [m]');
ylabel('y koordin�ta [m]');
hold on
plot(x(t==min(rovidT)),y(t==min(rovidT)),'ks','MarkerFaceColor','k')
plot(x(t==max(rovidT)),y(t==max(rovidT)),'rv','MarkerFaceColor','r')
legend('Poz�ci�','Kezd�pont','V�gpont');
grid on
end