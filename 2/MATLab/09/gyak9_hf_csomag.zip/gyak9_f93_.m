function gyak9_f93_()

end