function [tablazat]=gyak9_f91_()
tablazat = NaN;
end