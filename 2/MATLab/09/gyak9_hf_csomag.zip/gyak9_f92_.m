function gyak9_f92_()

end