function [abrak]=gyak9_f94_()
abrak(1) = figure;
abrak(2) = figure;
abrak(3) = figure;
abrak(4) = figure;
abrak(5) = figure;
end