function gyak9_f92_d1jjdq()
t=readtable('country_data.xls');
sortrows(t,'Number_of_spoken_languages','descend');
summary(t(1:10,4:7))
writetable(t,'country_data_reordered.csv','Filetype','text','delimiter','|')
end