function gyak9_f93_d1jjdq()
t=readtable('geodata.csv','ReadVariableNames',true,'Delimiter','\t');
X=reshape(t.X,33,45);
Y=reshape(t.Y,33,45);
Z=reshape(t.Z,33,45);
surf(X,Y,Z);
try
demcmap(Z)
catch
load cmp
colormap(cmp)
end
hold on
[U,V,W]=surfnorm(X,Y,Z);
quiver3(X,Y,Z,U,V,W,'m');
view(-15,60);
print('surf2.png','-r300','-dpng');
end