function [tablazat]=gyak9_f91_d1jjdq()
t = 0:.001:pi;
y = 5*sin(3*exp(t));
ertekeles = cell(size(t));
ertekeles(round(y)<2)={'el�gtelen'};
ertekeles(round(y)==2)={'el�gs�ges'};
ertekeles(round(y)==3)={'k�zepes'};
ertekeles(round(y)==4)={'j�'};
ertekeles(round(y)==5)={'jeles'};
tablazat = table(t',y',ertekeles','VariableNames',{'ido','eredmeny','ertekeles'});
end