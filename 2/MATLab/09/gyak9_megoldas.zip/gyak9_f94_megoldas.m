function [abrak]=gyak9_f94_d1jjdq()
abrak(1) = figure;
%% Els� k�p gener�l�sa
load house.mat
H1 = house*A1;
H2 = house*A2;
H3 = house*A3;
H4 = house*A4;
subplot(2, 2, 1);
plot(H1(:,1),H1(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A1', 'FontSize', 20, 'FontWeight', 'bold');
subplot(2, 2, 2);
plot(H2(:,1),H2(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A2', 'FontSize', 20, 'FontWeight', 'bold');
subplot(2, 2, 3);
plot(H3(:,1),H3(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A3', 'FontSize', 20, 'FontWeight', 'bold');
subplot(2, 2, 4);
plot(H4(:,1),H4(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A4', 'FontSize', 20, 'FontWeight', 'bold');
%% 2.
abrak(2) = figure;
load('polinom.mat');
meresiPozicio=meresiPozicio;
mertErtekek=mertErtekek;

polinomEgyutthatok = polyfit(meresiPozicio,mertErtekek,2);
illesztettErtekek = polyval(polinomEgyutthatok,meresiPozicio);
idoNagyobbLepeskozzel=linspace(meresiPozicio(1),meresiPozicio(end),5);
illesztettErtekekPontatlan = polyval(polinomEgyutthatok,idoNagyobbLepeskozzel);

gyokok=roots(polinomEgyutthatok);
predikaltTartomany = 4:0.1:8;
predikaltErtekek = polyval(polinomEgyutthatok,predikaltTartomany);

polinomEgyutthatokHatodfokra = polyfit(meresiPozicio,mertErtekek,6);

illesztettErtekekHatodfokra = polyval(polinomEgyutthatokHatodfokra,meresiPozicio);
predikaltErtekekHatodfokra = polyval(polinomEgyutthatokHatodfokra,predikaltTartomany);

hold on;
title('Polinom illesztes','FontSize',14);
xlabel('X ertek','FontSize',12,'FontWeight','bold');
ylabel('Y ertek','FontSize',12,'FontWeight','bold');
plot(meresiPozicio,mertErtekek,'k.');
plot(meresiPozicio,illesztettErtekek,'r','LineWidth',2);
plot(idoNagyobbLepeskozzel,illesztettErtekekPontatlan,'b--','LineWidth',2);
plot(gyokok,zeros(size(gyokok)),'kx','LineWidth',2,'MarkerSize',20);
plot(predikaltTartomany,predikaltErtekek,'g','LineWidth',2);
plot(meresiPozicio,illesztettErtekekHatodfokra,'m:','LineWidth',2);
plot(predikaltTartomany,predikaltErtekekHatodfokra,'c--','LineWidth',2);
plot([meresiPozicio(1), 8], [0, 0], 'k--');
legend('Zajos adatok', ...
    '2. foku illesztes',...
    '2. foku illesztes keves ponttal',...
    '2. foku gyokok',...
    '2. foku predikcio',...
    '6. foku illesztes',...
    '6. foku predikcio',...
    'Location','NorthWest');
%% 3.
abrak(3) = figure;
% kornyezeti kapacitasok (eltartokepesseg)
mu1 = 200; % zsakmany
mu2 = 300; % ragadozo
% a rendszert leiro diffegyenlet-rendszer
PredPrey = @(t,y) [(1-y(2)/mu2)*y(1);
    -(1-y(1)/mu1)*y(2)];
% kezdeti ertekek
y0 = [100;  % zsakmany
    150]; % ragadozo

% megoldas
[t_pp,y_pp] = ode45(PredPrey, [0 20], y0);

% kirajzolas
subplot(2, 1, 1);
hold on;
plot(t_pp,y_pp(:, 1), 'g', 'LineWidth', 2);
plot(t_pp,y_pp(:, 2), 'b', 'LineWidth', 2);
title('Predator-Prey Modell', 'FontSize', 14);
xlabel('t', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('egyedszam', 'FontSize', 12, 'FontWeight', 'bold');
legend('zsakmany','ragadozo');

% fazisgorbe
subplot(2, 1, 2);
plot(y_pp(:,1), y_pp(:,2));
title('Fazisgorbe', 'FontSize', 14);
xlabel('zsakmanyok szama', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('ragadozok szama', 'FontSize', 12, 'FontWeight', 'bold');
%% 4.
abrak(4) = figure;
[X, Y] = meshgrid(-1:0.01:1);
R = sqrt(X.^2 + Y.^2);
Z = 0.5.*sin(R).*cos(R);

hold on;
grid on;
surf(X, Y, Z);
C = contour(X, Y, Z);
clabel(C);
colorbar;
xlabel('x ertek', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y ertek', 'FontSize', 12, 'FontWeight', 'bold');
zlabel('z ertek', 'FontSize', 12, 'FontWeight', 'bold');
title('0.5sin(r)cos(r)', 'FontSize', 14);
view(20, 20);
%% 5.
abrak(5) = figure;
fid=fopen('84.text');
params=fscanf(fid,'%f',6);
[data.X,data.Y]=meshgrid(params(1):params(2):params(3),params(4):params(5):params(6));
data.Z=fscanf(fid,'%f',[21,inf]);
data.xlabel='x';
data.ylabel='y';
data.zlabel='z';
data.title='a betoltott adatpont-felho';
data.fontsize=16;
plot3(data.X,data.Y,data.Z,'*g')
hold on
c=contour3(data.X,data.Y,data.Z,6);
clabel(c);  
colorbar
title(data.title,'FontSize',data.fontsize);
xlabel(data.xlabel,'FontSize',data.fontsize);
ylabel(data.ylabel,'FontSize',data.fontsize);
zlabel(data.zlabel,'FontSize',data.fontsize);
grid on
set(gca,'FontSize',data.fontsize);
fclose(fid);
%% K�pek ment�se
for ind=1:length(figures)
    fname=sprintf('f%02d',ind);
    % LaTeX
    print(abrak(ind),'-depsc2','-r300',[fname '.eps'])
    % Word
    print(abrak(ind),'-dpng','-r300',[fname '.png'])
end
end