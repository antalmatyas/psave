%% T�bl�zat
t=table(v1,v2,v3,'VariableNames',{'o1','o2','o3'})
ft=readtable('foldrajzi.xls','ReadVariableNames',true);
summary(ft)
writetable(ft,'foldrajzi.xlsx','WriteVariableNames',true)
writetable(ft,'foldrajzi.csv','WriteVariableNames',true, 'FileType','text','Delimiter',';')
%% �br�k ment�se k�pk�nt
f1=figure;
surf(peaks)
title('Peaks fel�let','FontSize',22)
xlabel('x','FontSize',20)
ylabel('y','FontSize',20)
zlabel('z','FontSize',20)
colorbar
set(gca,'FontSize',20)
print(f1,'-dpng','-zbuffer','-r300','surf1.png')