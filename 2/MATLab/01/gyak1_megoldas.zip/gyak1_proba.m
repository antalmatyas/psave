a=5; b=2.4;
[c,d,e,f,g,h,k,l,m,n,o,p]=gyak1_megoldas(a,b);
