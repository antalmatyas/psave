function [c,d,e,f,g,h,k,l,m,n,o,p]=gyak1_megoldas(a,b)
c = b^(1/a);
d = a^b;
e = log(b)/log(a);
f = 5.21^((log(pi^(1/3))/log(b))^a);
atfogo = sqrt(a^2+b^2);
g = asin(a/atfogo);
h = asind(a/atfogo);
k = asin(b/atfogo);
l = asind(b/atfogo);
m = primes(b^a);
n = factorial(a*b);
o = factor(10*a*b);
p = b^2*pi;
end