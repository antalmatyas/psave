function [abra, hitelesitettMeresiErtekek, elsoSzenzorHelyesMereseiSzovegben,...
    szenzorokDeliMeresenekAtlagaSzovegben]=gyak3_f32_megoldas(legnyomasErtekek)
% A bemenet�nk egy 900 �s 1090 k�z�tti v�letlenszer� �rt�keket tartalmaz�
% 4x3x31-es m�trix.
%% Ide j�het az 1. r�szfeladathoz sz�ks�ges adat kigy�jt�se
adatsor1 = squeeze(legnyomasErtekek(1, 3, :));
joErtekekIndexe = find(adatsor1>=930 & adatsor1<=1060);
joErtekek = adatsor1(joErtekekIndexe);

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n
hold on;
plot([1 31], [930 930], 'm', 'LineWidth', 2);
plot([1 31], [1060 1060], 'm', 'LineWidth', 2);
plot(adatsor1, '-.ko', 'LineWidth', 3, 'MarkerSize', 7);
plot(joErtekekIndexe, joErtekek, 'o', 'LineWidth', 2,...
    'MarkerSize', 7, 'MarkerFaceColor', [0 1 0], ...
    'MarkerEdgeColor', [1 0 0]);
ylim([890, 1100]);
xlim([1, 31]);
set(gca, 'FontSize', 12);
title('Els� szenzor, esti m�r�s, minden nap', 'FontSize', 14);
xlabel('napok sz�ma', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('l�gk�ri nyom�s [hPa]', 'FontSize', 12, 'FontWeight', 'bold')

%% Itt legyenek a tov�bbi r�szfeladatok
% 2)
hitelesitettMeresiErtekek = legnyomasErtekek;
hitelesitettMeresiErtekek(hitelesitettMeresiErtekek<930 |...
    hitelesitettMeresiErtekek>1060) = 0;
% 3)
adatsor2 = squeeze(hitelesitettMeresiErtekek(1, 3, 11:20));
darab = sum(adatsor2>0);
elsoSzenzorHelyesMereseiSzovegben = sprintf(...
    ['Helyes m�r�si �rt�kek darabsz�ma (els� szenzor, esti m�r�s, '...
        '11-20. napokra): %i\n'], darab);
% 4)
adatsor3 = squeeze(hitelesitettMeresiErtekek(2:4, 2, :));
helyesMeresDb = sum((adatsor3>0), 2);
osszegzettMeres = sum(adatsor3, 2);
atlagok = osszegzettMeres ./ helyesMeresDb;
% 5)
szenzorokDeliMeresenekAtlagaSzovegben = sprintf(...
    ['A m�sodik szenzor d�li �tlaga: %0+9.3f, a harmadiknak: ' ...
    '%0+9.3f �s a negyediknek: %0+9.3f\n'], atlagok(1), atlagok(2), atlagok(3));
end