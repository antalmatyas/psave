function [B,C,d,e,f]=gyak3_f31_megoldas(A)

B = squeeze(A(:, 1, :));
C = squeeze(A(:, 2, :));

d = sum(max(B, [], 2));
e = mean(min(C));

f = sprintf('B-ben a sorok maximum�nak �sszege: %4.2f, m�g C-ben az oszlopok minimum�nak �tlaga: %4.2f\n', ...
    d, e);
end