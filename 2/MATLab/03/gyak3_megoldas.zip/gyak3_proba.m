rng(1)
A=rand(5,2,3);
[B,C,d,e,f]=gyak3_f31_megoldas(A);

rng(1)
legnyomasErtekek = 900 + round(190*rand(4, 3, 31));
[abra, hitelesitettMeresiErtekek, elsoSzenzorHelyesMereseiSzovegben,...
    szenzorokDeliMeresenekAtlagaSzovegben]=gyak3_f32_megoldas(legnyomasErtekek);