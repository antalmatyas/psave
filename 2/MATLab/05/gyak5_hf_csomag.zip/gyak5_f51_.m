function abra=gyak5_f51_(a,b,c,d,e,f)

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n

end