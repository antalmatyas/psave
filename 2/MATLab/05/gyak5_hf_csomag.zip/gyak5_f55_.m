function abra=gyak5_f55_(meresiPozicio,mertErtekek,a,b)

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n

end