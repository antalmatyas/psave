function abra=gyak5_f53_(a,b,c,d,e,t0)

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n

end