function abra=gyak5_f52_(a,b,c,d)

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n

end