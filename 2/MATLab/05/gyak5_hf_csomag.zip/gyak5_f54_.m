function kimenetiSzoveg=gyak5_f54_(a,b)
kimenetiSzoveg = NaN;
end