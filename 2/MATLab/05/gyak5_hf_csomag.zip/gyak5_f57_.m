function kimenetiSzoveg=gyak5_f57_(meresiPozicio,mertErtekek,integralasiModszer)
kimenetiSzoveg = NaN;
end