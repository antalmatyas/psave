function abra=gyak5_f55_megoldas(meresiPozicio,mertErtekek,a,b)

polinomEgyutthatok = polyfit(meresiPozicio,mertErtekek,2);

illesztettErtekek = polyval(polinomEgyutthatok,meresiPozicio);
idoNagyobbLepeskozzel=linspace(meresiPozicio(1),meresiPozicio(end),5);
illesztettErtekekPontatlan = polyval(polinomEgyutthatok,idoNagyobbLepeskozzel);

gyokok=roots(polinomEgyutthatok);

predikaltTartomany = a:b:2*a;
predikaltErtekek = polyval(polinomEgyutthatok,predikaltTartomany);

polinomEgyutthatokHatodfokra = polyfit(meresiPozicio,mertErtekek,6);

illesztettErtekekHatodfokra = polyval(polinomEgyutthatokHatodfokra,meresiPozicio);
predikaltErtekekHatodfokra = polyval(polinomEgyutthatokHatodfokra,predikaltTartomany);
%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n
hold on;
title('Polinom illeszt�s','FontSize',14);
xlabel('X �rt�k','FontSize',12,'FontWeight','bold');
ylabel('Y �rt�k','FontSize',12,'FontWeight','bold');
plot(meresiPozicio,mertErtekek,'k.');
plot(meresiPozicio,illesztettErtekek,'r','LineWidth',2);
plot(idoNagyobbLepeskozzel,illesztettErtekekPontatlan,'b--','LineWidth',2);
plot(gyokok,zeros(size(gyokok)),'kx','LineWidth',2,'MarkerSize',20);
plot(predikaltTartomany,predikaltErtekek,'g','LineWidth',2);
plot(meresiPozicio,illesztettErtekekHatodfokra,'m:','LineWidth',2);
plot(predikaltTartomany,predikaltErtekekHatodfokra,'c--','LineWidth',2);
plot([meresiPozicio(1), 2*a], [0, 0], 'k--');
legend('Zajos adatok', ...
	'2. fok� illeszt�s',...
	'2. fok� illeszt�s kev�s ponttal',...
	'2. fok� gy�k�k',...
	'2. fok� predikci�',...
	'6. fok� illeszt�s',...
	'6. fok� predikci�',...
	'Location','NorthWest');
end