function abra=gyak5_f53_megoldas(a,b,c,d,e,t0)
% polinom
P = [a b c d];
% x a kirajzol�shoz
x = -e:0.001:e;
% y a kirajzol�shoz
y = polyval(P,x);
% fv. �rt�k
y0 = polyval(P,t0);
% a deriv�l�s "felbont�sa"
dt0 = 1E-6;
% t0 k�r�li k�rnyezet
t_tart= [t0-dt0 t0+dt0];
% a fv. �rt�kei ugyanitt
y_tart= polyval(P,t_tart);
% k�l�nbs�gek
dt_tart= diff(t_tart);
dy_tart= diff(y_tart);
% deriv�lt
dy_dt0 = dy_tart/dt_tart;

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n
hold on;
plot(x,y);
plot(t0,y0,'ko');
plot([t0-1 t0+1],[y0-dy_dt0 y0+dy_dt0],'r');
title('�rint� adott pontban', 'FontSize', 14);
xlabel('x', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y', 'FontSize', 12, 'FontWeight', 'bold');
legend('fv. �rt�kek', 'deriv�l�si hely', '�rint� egyenes', ...
    'Location', 'NorthWest');
end