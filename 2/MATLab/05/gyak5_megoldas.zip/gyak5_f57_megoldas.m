function eredmeny=gyak5_f57_megoldas(meresiPozicio,mertErtekek,integralasiModszer)
% Illesztett polinom egyutthat�k
polinomEgyutthatokHatodfokra = polyfit(meresiPozicio,mertErtekek,6);
% Gy�k�k
gyokok=roots(polinomEgyutthatokHatodfokra);

tizPont=linspace(gyokok(6),gyokok(1)/2,9);
tizPontosErtekekHatodfokra = polyval(polinomEgyutthatokHatodfokra,tizPont);
switch integralasiModszer
    case 'osszeadas'
        % �sszead�ssal
        eredmeny = sum(tizPontosErtekekHatodfokra)*(tizPont(2)-tizPont(1));
    case 'trapez'
        % Trap�zzal
        eredmeny = trapz(tizPont,tizPontosErtekekHatodfokra);
    case 'integral'
        % Anonim f�ggv�ny seg�ts�g�vel
        % Anonim f�ggv�ny l�trehoz�sa
        hatodfokuPolinomFuggveny = @(x) polyval(polinomEgyutthatokHatodfokra,x);
        
        % Integr�l�s
        eredmeny = integral(hatodfokuPolinomFuggveny,gyokok(6),gyokok(1)/2);
    otherwise
        eredmeny = NaN;
end

end