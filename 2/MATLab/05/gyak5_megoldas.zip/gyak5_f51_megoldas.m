function abra=gyak5_f51_megoldas(a,b,c,d,e,f)
% polinom letrehozas
P = [a b c d];
% x vektorok definialasa a megfelelo lepeskozzel
x1 = e:1:f;
x2 = e:0.001:f;
% kiertekeles
y1 = polyval(P,x1);
y2 = polyval(P,x2);
% gyokok kiszamitasa
r = roots(P);
%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n
hold on;
% behelyettesitesek
plot(x1,y1,'r');
plot(x2,y2,'b');
% gyokok
plot(r,zeros(size(r)),'ko');
% 0 szint
plot([-3 1.5],[0 0],'k--');
title('Polinom', 'FontSize', 14);
xlabel('x �rt�k', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y �rt�k', 'FontSize', 12, 'FontWeight', 'bold');
legend('1-es l�p�sk�z', '0.001-es l�p�sk�z', 'gy�k�k', ...
    'Location', 'SouthEast');
end