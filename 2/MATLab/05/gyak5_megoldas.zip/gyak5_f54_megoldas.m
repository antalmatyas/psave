function kimenetiSzoveg=gyak5_f54_megoldas(a,b)

x = 0:b:a;

z1 = sum(sin(x))*b;
z2 = trapz(x,sin(x));
f1 = @(x) sin(x);
z3 = integral(f1,x(1),x(end));

kimenetiSzoveg = sprintf(['Integr�l�si eredm�nyek:\n\t�sszead�ssal: %3.3f\n\t'...
'Trap�zszab�llyal: %3.3f\n\tF�ggv�nnyel: %3.3f\n'],...
z1, z2, z3);

end