function abra=gyak5_f52_megoldas(a,b,c,d)
% id�vektor
t1 = a:c:b;
t2 = a:d:b;
% fv. �rt�kek
s1 = sin(t1);
s2 = sin(t2);
% k�l�nbs�gek sz�mol�sa
% ET:
dt1 = diff(t1);
dt2 = diff(t2);
% EK:
ds1 = diff(s1);
ds2 = diff(s2);
% differenciah�nyados
ds1_dt1 = ds1./dt1;
ds2_dt2 = ds2./dt2;

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n
% f�ggv�ny
subplot(1, 2, 1)
hold on;
plot(t1,s1,'bo-');
plot(t2,s2,'r.-');
title('szinusz k�l�nb�z� felbont�sokkal', 'FontSize', 14);
xlabel('t', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('fv. �rt�k', 'FontSize', 12, 'FontWeight', 'bold');
legend('c felbont�s', 'd felbont�s');
% deriv�lt
subplot(1, 2, 2);
hold on;
plot(t1(2:end),ds1_dt1,'bo-');
plot(t2(2:end),ds2_dt2,'r.-');
title('numerikus deriv�ltak', 'FontSize', 14);
xlabel('t', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('dy / dt', 'FontSize', 12, 'FontWeight', 'bold');
legend('c felbont�s', 'd felbont�s');
end