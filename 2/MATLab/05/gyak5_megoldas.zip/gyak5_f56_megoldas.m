function abra=gyak5_f56_megoldas(meresiPozicio,mertErtekek,a,b)
% Illesztett polinom egy�tthat�k
polinomEgyutthatokHatodfokra = polyfit(meresiPozicio,mertErtekek,6);

% Polinom ertekei a [-4;8] intervallumon es kirajzolas
bPont=linspace(-a,2*a,b);
tizBPont=linspace(-a,2*a,10*b);
bPontosErtekekHatodfokra = polyval(polinomEgyutthatokHatodfokra,bPont);
tizBPontosErtekekHatodfokra = polyval(polinomEgyutthatokHatodfokra,tizBPont);

% Numerikus deriv�lt
% K�l�nbs�gek kisz�m�t�sa
% �rtelmez�si tartom�ny
dBPont = diff(bPont);
dTizBPont = diff(tizBPont);
% �rt�kk�szlet
dBPontosErtekekHatodfokra = diff(bPontosErtekekHatodfokra);
dTizBPontosErtekekHatodfokra = diff(tizBPontosErtekekHatodfokra);

% Differencia h�nyados
differenciaHanyadosBPontos = dBPontosErtekekHatodfokra./dBPont;
differenciaHanyadosTizBPontos = dTizBPontosErtekekHatodfokra./dTizBPont;
%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n
subplot(1, 2, 1);
hold on;
title('Polinom illeszt�s','FontSize',14);
xlabel('t �rt�k','FontSize',12,'FontWeight','bold');
ylabel('Y �rt�k','FontSize',12,'FontWeight','bold');
plot(bPont,bPontosErtekekHatodfokra,'b-o');
plot(tizBPont,tizBPontosErtekekHatodfokra,'r.-');
legend('b pontos',...
	'10b pontos',...
	'Location','SouthWest');
subplot(1, 2, 2)
hold on;
title('Numerikus deriv�lt','FontSize',14);
xlabel('t �rt�k','FontSize',12,'FontWeight','bold');
ylabel('dY �rt�k','FontSize',12,'FontWeight','bold');
plot(bPont(2:end),differenciaHanyadosBPontos,'bo-');
plot(tizBPont(2:end),differenciaHanyadosTizBPontos,'r.-');
legend('b pontos',...
	'10b pontos',...
	'Location','SouthWest');
end