function abra=gyak6_f62_megoldas(y0,t)
% a rendszert le�r� diffegyenlet-rendszer
kemiaiReakcio = @(t,y) [1.2*y(1)+4.1*y(2)-1.7*y(3);
                        -8*y(1)-1.4*y(2)+2.1*y(3);
                        2.1*y(1)-7.2*y(2)+1.3*y(3)];
% megold�s
[t_chr,y_chr] = ode45(kemiaiReakcio,t,y0);

% felt�tel
y_felt = y_chr(y_chr(:,1)>y_chr(:,2) & y_chr(:,3)>y_chr(:,1),1);
t_felt = t_chr(y_chr(:,1)>y_chr(:,2) & y_chr(:,3)>y_chr(:,1));

% kirajzol�s
abra = figure;
hold on;
plot(t_chr,y_chr(:, 1), 'b', 'LineWidth', 2);
plot(t_chr,y_chr(:, 2), 'k', 'LineWidth', 2);
plot(t_chr,y_chr(:, 3), 'r', 'LineWidth', 2);
plot(t_felt,y_felt, 'gs', 'LineWidth', 2,'MarkerFaceColor','g');
xlabel('id�', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('koncentr�ci�', 'FontSize', 12, 'FontWeight', 'bold');
legend('A','B','C','Location','SouthWest');
end