function abra=gyak6_f61_megoldas(y0,t)
% elsorendu, ketvaltozos differencialegynelet megoldasa,
% Lotka-Volterra ragadozo-zsakmany modell

% kornyezeti kapacitasok (eltartokepesseg)
mu1 = 200; % zsakmany
mu2 = 300; % ragadozo
% a rendszert leiro diffegyenlet-rendszer
PredPrey = @(t,y) [(1-y(2)/mu2)*y(1);
    -(1-y(1)/mu1)*y(2)];
% megoldas
[t_pp,y_pp] = ode45(PredPrey,t,y0);

% kirajzolas
abra = figure;
subplot(2, 1, 1);
hold on;
plot(t_pp,y_pp(:, 1), 'g', 'LineWidth', 2);
plot(t_pp,y_pp(:, 2), 'b', 'LineWidth', 2);
title('Predator-Prey Modell', 'FontSize', 14);
xlabel('t', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('egyedsz�m', 'FontSize', 12, 'FontWeight', 'bold');
legend('zs�km�ny','ragadoz�');

% fazisgorbe
subplot(2, 1, 2);
plot(y_pp(:,1), y_pp(:,2));
title('F�zisg�rbe', 'FontSize', 14);
xlabel('zs�km�nyok sz�ma', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('ragadoz�k sz�ma', 'FontSize', 12, 'FontWeight', 'bold');

end