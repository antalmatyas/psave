y0 = [100, 150];
t = [0, 20];
abra1=gyak6_f61_megoldas(y0,t);
y0 = [5, 7, 9];
t = [0, 1.4];
abra2=gyak6_f62_megoldas(y0,t);