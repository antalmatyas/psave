function abra=gyak6_f62_(y0,t)


%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n


end