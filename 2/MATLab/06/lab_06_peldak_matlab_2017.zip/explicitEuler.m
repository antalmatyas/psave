function [t_out, y_out] = explicitEuler(F, tspan, y0)
% Egyszeru differencialegyenelt-megoldo, explicit Euler 
% modszer alapjan.
% Csak szemleltetesi celu, ne hasznaljuk kesobb, mert 
% pontatlan.
% F: derivaltfuggveny
% tspan: idoskala (elso es utolso pontja)
% y0: kezdeti ertek

    
    % felosztas (adatpontok szama):
    felosztas = 200;
    % lepeskoz:
    h = (tspan(end)-tspan(1))/felosztas;
    
    % kimeneti vektorok
    t_out = zeros(felosztas+1, 1);
    y_out = zeros(felosztas+1, length(y0)); % az oszlopok szama azert 
    % igazodik a kezdetiertek elemszamahoz, hogy tobbdimenzios problema 
    % eseten is mukodjon a megoldonk
    
    t_out(1) = tspan(1);
    y_out(1) = y0;
    for ind=2:felosztas+1
        t_out(ind) = t_out(ind-1)+h;
        % a derivalt aktualis erteke:
        ydot = F(t_out(ind), y_out(ind-1));
        % a derivalt erteke alapjan az allapot aktualis erteke
        y_out(ind) = y_out(ind-1) + h*ydot;
    end
end