% Saj�t keszites�, explicit Euler m�dszeren alapul� diffegyenlet-megold�
% tesztel�se
% 2015. 04. 17.

% a deriv�ltf�ggv�ny defin�ci�ja (anonim f�ggv�nyk�nt):
F = @(t,y) 2*y;

% a megold�s kisz�m�t�sa:
[t1, y1] = explicitEuler(F, [0 3], 1);

% rajzoljuk ki
figure;
hold on;
plot(t1, y1,'r-', 'LineWidth', 2);
% be�p�tett megold� haszn�lat�val is sz�moljuk ki a megold�st:
[t45, y45] = ode45(F, [0 3], 1);
% rajzoljuk ki ezt is:
plot(t45, y45, 'bo-', 'LineWidth', 2);
% �s az analitikus megold�st is:
plot(t45, exp(2.*t45),'k--','LineWidth',2);
xlim([0, 3]);

legend('explicit Euler', 'ode45', 'analitikus', 'Location', 'NorthWest');
xlabel('t', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('�rt�kek', 'FontSize', 12, 'FontWeight', 'bold');
title('Differenci�legyenlet megold�sa', 'FontSize', 14);
