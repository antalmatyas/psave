% Els�rend�, egyv�ltoz�s differenci�legynelet megold�sa,
% egy egyszer� �ramk�rben egy kapacit�s t�lt��ram�nak viselked�se
% 2015. 04. 17.

V0 = 2; % V
R = 1E3; % Ohm
C = 5E-4; % Farad
tau = R*C;

% a diffegyenlet megad�sa anonim fv.-k�nt
F = @(t,y) -1/tau*y;
% megold�s a [0 1] intervallumon, V0/R kezdeti �rt�kre
[t_rc, y_rc] = ode45(F, [0 1], V0/R);

figure;
hold on;
plot(t_rc, y_rc, 'LineWidth',2);

% analitikus megold�s
t=0:0.001:1;
I=V0/R*exp(-t/tau);
plot(t, I, 'r--', 'LineWidth',2);

title('Kondenz�tor kis�l�se', 'FontSize', 14);
xlabel('t [s]', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('i(t) [A]', 'FontSize', 12, 'FontWeight', 'bold');
legend('ode45','analitikus');
