function ydot=rugoegyenlet(t, x, m, D, C, F)
    % M�sodrend� diffegyenlet megold�sa: sz�tszedj�k k�t els�rend�re
    % Az �llapotvektor y=[y1;y2] alak�,
    % ahol y1=kit�r�s, y2=sebess�g: 
    % Az �llapotvektor deriv�ltjai
    ydot = zeros(2,1);
    % ahol ydot(1) maga a sebess�g
    ydot(1)=x(2);
    % es ydot(2) pedig a gyorsul�sra rendezett egyenlet
    ydot(2)=-D/m*x(1)-C/m*x(2)+F/m;
end
