% Els�rend�, k�tv�ltozos differenci�legynelet megold�sa,
% reakci�ba l�p� folyad�kok kever�sekor a koncentr�ci�szintek
% viselked�se
% 2015. 04. 17.

% a diffegyenlet megad�sa anonim fv.-k�nt
F = @(t,y) [-10*y(1) + 50*y(2);
             10*y(1) - 50*y(2)];

% megold�s
[t, y] = ode45(F,[0 0.5], [0 1]);

% A diffegyenlet megadhat� k�l�n .m f�jlban is, ekkor a megold�s:
% [t, y] = ode45(@chem,[0 0.5], [0 1]);
% VAGY:
% [t, y] = ode45('chem',[0 0.5], [0 1]);

% �br�zol�s
figure;
hold on;
plot(t,y(:,1),'k','LineWidth',2);
plot(t,y(:,2),'r','LineWidth',2);

title('K�miai reakci�', 'FontSize', 14);
xlabel('id�', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('koncentr�ci�', 'FontSize', 12, 'FontWeight', 'bold');
legend('A','B');

