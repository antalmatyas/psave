% M�sodrend� differenci�legynelet megold�sa,
% csillap�tott rezg�mozg�s vizsg�lata
% 2015. 04. 17.

% t�meg
m = 1; % kg == (Ns^2)/m

% rug��lland�
D = 10; % N/m

% csillap�t�si t�nyez�
C=0.2; % (Ns)/m

% k�ls� er�
F=-10; % N

% id�ablak
tspan=[0 60];

% kezdeti felt�telek ([kit�r�s; sebess�g])
x0=[1; 0];

% ODE megold�sa
[t, x] = ode45(@(t,x) rugoegyenlet(t, x, m, D, C, F), tspan, x0);

% kirajzol�s
figure;
hold on;
plot(t,x(:,1),'b', 'LineWidth', 2);
plot(t,x(:,2),'r', 'LineWidth', 2);
title('Rezg�mozg�s', 'FontSize', 14);
xlabel('id� [s]', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('�rt�k', 'FontSize', 12, 'FontWeight', 'bold');
legend('Kit�r�s [m]','Sebess�g [m/s]');

