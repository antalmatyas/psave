function dydt = chem(t, y)
% folyadekok keveresekor a koncentracioszintek viselkedese --- maga a
% diffegyenlet:

    % y - allapotvaltozo
    dydt = zeros(2,1);
    
    % dA/dt
    dydt(1) = -10*y(1) + 50*y(2);
    % dB/dt
    dydt(2) = 10*y(1) - 50*y(2);
end
