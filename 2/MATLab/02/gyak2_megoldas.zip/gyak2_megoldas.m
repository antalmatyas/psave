function [c,d,e,f,g,h,k,l,m,n,o,p,q,r,s]=gyak2_megoldas(a,b,x)
c = x>=a & x<=b;
d = x(c); 
e = find(x>=a & x<=b);
f = mean(x);
g = x>=f & x<a;
h = x(g);
k = x>=a & x<=b;
l = x(k);
[m, n] = max(l);
o = sum(k);
t = linspace(eps,pi,100);
fv = sin(t)./(4.7*t+3)+0.1*cos(t.^2);
[fv_max, fv_max_index] = max(fv);
p = t(fv_max_index);
q = fv_max;
%% Ide ker�lj�n a 2.6-os feladat megold�sa 
r = figure; % ez ut�n a sor ut�n
t = 5:10;
fv = t./sin(t);
plot(t,fv,'ro--');
title('abracim')
xlabel('t');
ylabel('y ertek');
%% Ide ker�lj�n a 2.7-es feladat megold�sa 
s = figure; % ez ut�n a sor ut�n
t = 2:14;
fv1 = 0.5 - 0.2*exp(log(t).*cos(t));
fv2 = pi.^(0.1*t-3).*sin(t);
fv3 =  cos(t)./exp(sin(t));

subplot(2,2,1)
plot(t,fv1,'b--s');
title('balfelso')
xlim([2,14])
xlabel('t');
ylabel('y ertek');

subplot(2,2,3)
plot(t,fv2,'k-^');
title('balalso')
xlim([2,14])
xlabel('t');
ylabel('y ertek');

subplot(2,2,[2,4])
plot(t,fv3,'r-*');
hold on;
grid on;
plot([2,14],[0,0],'k--')
title('jobboldal')
xlim([2,14])
xlabel('t');
ylabel('y ertek');

end