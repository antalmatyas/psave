function [struktura, abra]=gyak8_f84_(bemenetiFajl)
struktura = NaN;
abra = figure;
end