function [cellaTomb, abra]=gyak8_f81_(db)
cellaTomb = NaN;
abra = figure;
end