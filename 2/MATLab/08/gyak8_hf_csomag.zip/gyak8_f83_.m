function [tVektor, yMatrix, abra]=gyak8_f81_(bemenetiFajl)
tVektor = NaN;
yMatrix = NaN;
abra = figure;
end