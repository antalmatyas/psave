function [struktura, abra]=gyak8_f82_(db)
struktura = NaN;
abra = figure;
end