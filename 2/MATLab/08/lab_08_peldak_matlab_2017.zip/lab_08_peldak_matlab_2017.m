%% Példa 1

% cellatömb létrehozása
C1 = cell(3,2);

% feltöltés oszlopfolytonosan
C1{1,1} = 'szöveg';
C1{2,1} = 12;
C1{3,1} = [8.13, 14.86];
C1{1,2} = magic(5);
C1{2,2} = cell(2,4);
C1{3,2} = {1, 2, 3; 4, 5, 6};

% megjelenítés
cellplot(C1);
title('C1 tartalma');

% létrehozás ismert elemekből
C2 = {'szöveg', magic(5);
     12, cell(2,4);
     [8.13 14.86], {1, 2, 3; 4, 5, 6}};
 
% megjelenítés
figure;
cellplot(C2);
title('C2 tartalma');

%% Példa 2

c{1,1} = linspace(0,2*pi,1000);
c{2,1} = 'Sin(3t)';
c{2,2} = 'Cos(5t)';
c{2,3} = 'Sin(3t)*Cos(5t)';
c{3,1} = sin(3*c{1,1});
c{3,2} = cos(5*c{1,1});
c{3,3} = c{3,1}.*c{3,2};

figure;
for spi=1:size(c,2)
    subplot(3,1,spi);
    plot(c{1, 1}, c{3,spi},'k');%,'Linewidth',2);
    title(c{2,spi});
    xlabel('t');
    xlim([0, 2*pi]);
end

%% Példa 3

hallgato.nev = 'Kis Pista';
hallgato.szul_datum = '1992.03.24.';
hallgato.evfolyam = 3;
hallgato.osztalyzatok = [2 4 3 5 3 4 4 3];

hallgato

% idővektor
t = linspace(0,2*pi,1000);

% első ábra
% amit csinalunk: struct array
rajz(1).x = t;
rajz(1).y = sin(3*rajz(1).x);
rajz(1).cim = 'Sin(3t)';

% második ábra
rajz(2).x = t;
rajz(2).y = cos(5*rajz(2).x);
rajz(2).cim = 'Cos(5t)';

% harmadik ábra
rajz(3).x = t;
rajz(3).y = rajz(1).y .* rajz(2).y;
rajz(3).cim = [rajz(1).cim '*' rajz(2).cim];

% kirajzolás
figure;
for pli = 1:length(rajz)
    subplot(3,1,pli);
    plot(rajz(pli).x,rajz(pli).y,'k');
    title(rajz(pli).cim);
    xlabel('t')
    xlim([0 2*pi]);
end

%% formázott szöveg

x = [1.2 -3.3 4];
fprintf('x értékei: x(1) = %4.4f, x(2) = %3.1f, x(3) = %d \n',x);

fprintf('x értékei: x(1) = %+010.2f, x(2) = %+5.3f, x(3) = %d \n',x)

% A soron kovetkezo megse legyen, mert a g-t sehol mashol nem
% emlitjuk/hasznaljuk...
%fprintf('|%15.8f| es |%15.8g|\n', 100*pi, 100*pi)
% eredmeny: |   314.15926536| es |      314.15927|
% mivel: a formátum belseje ugye >>>field width.precision<<< alaku, amibol:
% - field width: Minimum number of characters to print, ... (ez ugye minden egyuttveve, legalabb ennyit kinyomtat)
% - precision:
%     - For %f, %e, or %E: Number of digits to the right of the decimal point.
%     - For %g or %G: Number of significant digits. (csak a szamjegyek, de a teljes szamban)
% 

%% formázott szöveg kiírás

% kiirando jel generalasa
% mintaveteli frekvencia
Fs=1000; % Hz
% idovektor
t=0:1/Fs:10; % s
% körfrekvencia
f=5; % Hz
% szinusz jelalak
s=sin(2*pi*f*t);

% az adott helyhez kepest vett relativ cimzes
% (lehet abszolut is, teljes utvonallal)
fs = filesep;
DIR_PATH=['.' fs 'files' fs];

% a kiirando fajl neve
filename='szinusz_fprintf.txt';

% a fajl eleresi utvonala (ha csak a fajlnevet
% adom meg, az aktualis konyvtarba menti)
file_path=[DIR_PATH filename];

% fajl megnyitasa irasra, ez utan az fid-val
% hivatkozok erre a fajlra
fid=fopen(file_path,'w');

% header irasa, hogy tudjuk, mi van a fajlban
% pl.: Szinusz (Fs = 1000)
fprintf(fid,['Szinusz (Fs = ' num2str(Fs) ') \n']);
fprintf(fid,'t sin \n');

% az iras utan nyitva marad a fajl, ezert irhatok meg bele formazott adatot

% irjuk bele a kiszamolt szinusz fuggvenyt
fprintf(fid,'%5.2f %4.4f\n',[t;s]);

% fajl bezarasa - FONTOS, ne felejtsuk el!
fclose(fid);


%% Fajlbol olvasas formázott szövegként 1 (fscanf) 
% az fscanf csak az alap formazo 
% karaktereket ismeri (lasd HELP)

% a beolvasando fajl neve (amit 
% az elobb kiirtunk)
filename='szinusz_fprintf.txt';

% a fajl eleresi utvonala
file_path=[DIR_PATH filename];

% fajl megnyitasa olvasasra
fid=fopen(file_path);

% fajl beolvasasa formazott
% szovegkent
% eloszor a header beolvasasa
% stringkent
Sheader=fscanf(fid,'%s',6); % 6 darab sztringet olvas be
% majd az adatok beolvasasa 
% lebegopontos szamkent
Sdata=fscanf(fid,'%f %f',[2 inf]); % [m,n]: Read at most m*n elements in column order. n can be inf, but m cannot.

% fajl bezarasa
fclose(fid);

% beolvasott adatok kirajzolasa
figure;
plot(Sdata');
legend('t','sin');
title(Sheader);


%% Fajlbol olvasas formázott szövegként 2 (textscan)
% a textscan-nek lehet regularis 
% kifejezest is adni (lasd HELP)
% 
% EESS
% 
% a kimenetet cell-array-be teszi

% a beolvasando fajl neve (meg 
% mindig ugyanaz)
filename='szinusz_fprintf.txt';

% a fajl eleresi utvonala
file_path=[DIR_PATH filename];

% fajl megnyitasa olvasasra
fid=fopen(file_path);

% fajl beolvasasa cellatömbbe
% header beolvasasa
Sheader_ts=textscan(fid,'%s',6);
% adatok beolvasasa
Sdata_ts=textscan(fid,'%f %f');

% fajl bezarasa
fclose(fid);

% beolvasott adatok kirajzolasa
tt = Sdata_ts{1};
data = Sdata_ts{2};

% cim konvertalasa:
abracim = cell2mat(Sheader_ts{1}(:)'); % egy elemu cell-array, melyben 
% stringek vannak egy oszlopban... ezt meg karakter-matrix formatumra
% alakitjuk a cell2mat-tal

figure;
plot(tt,data);
title(abracim);

% binaris modu fajlkezeles

% a kiirando fajl neve
filename='szinusz_fwrite.bin'; % nem kotelezo a bin

fs = filesep;
dir_path = ['.', fs];
file_path=[dir_path, filename];

% fajl megnyitasa irasra, ez utan az
% fid-val hivatkozok erre a fajlra
fid=fopen(file_path,'w');

t = linspace(0.1, 3*pi, 25);
y = sin(t);

% adatok kiirasa binarisan, double-kent
fwrite(fid,[t' y'],'double');
% fajl bezarasa, valtozok torlese
fclose(fid);

clear('t', 'y'); % lehetne meg a formaja: clear t, y

% ujranyitas, visszaolvasas
fid=fopen(file_path, 'r'); % vagy siman fid=fopen(file_path);

data = fread(fid, inf, 'double');
data = reshape(data, length(data)/2, 2);

fclose(fid);

figure;
plot(data(:, 1), data(:, 2), 'b.-');

% matlab archivum
    
% csak hogy tiszta legyen a munkater
clear all;

% a kiirando fajl neve
filename='sajat_matlab_archivum.mat';

fs = filesep;
dir_path = ['.', fs];
file_with_path=[dir_path, filename];

t = linspace(0.1, 3*pi, 25);
y = sin(t);
dummy1 = rand(20, 2);
% most mi van a munkaterben?

% a valtozok kimentese: save utasitassal
save(file_with_path, 't', 'y')
% valtozok torlese a munkaterbol
clear('t', 'y', 'dummy1'); % lehetne meg a formaja: clear t, y;
% vagy egyszerre minden: clear all;
% most mi van a munkaterben?
% valtozok szelektiv betoltese -- ha tudod elore mi van benne...
load(file_with_path, 't');
% most mi van a munkaterben?
load(file_with_path, 'y');
% most mi van a munkaterben?
% lehetett volna egyszerre mindent: load(file_with_path);

figure;
plot(t, y, 'b.-');