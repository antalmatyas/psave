function [struktura, abra]=gyak8_f82_d1jjdq(db)
struktura.x = linspace(0,2*pi,db);
struktura.nev = {'Sin(3t)', 'Cos(5t)' , 'Sin(3t)*Cos(5t)'};
struktura.y = {sin(3*struktura.x),...
    cos(5*struktura.x) ,...
    sin(3*struktura.x).*cos(5 * struktura.x)};
abra = figure;
for ind = 1:length(struktura.nev)
    subplot(3,1,ind)
    plot(struktura.x,struktura.y{ind});
    title(struktura.nev{ind});
    xlabel('t');
end
end