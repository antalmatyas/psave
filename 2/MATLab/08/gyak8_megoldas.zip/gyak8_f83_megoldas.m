function [tVektor, yMatrix, abra]=gyak8_f83_d1jjdq(bemenetiFajl)
fid=fopen(bemenetiFajl);
params=fscanf(fid,'%f',4);
fclose(fid);
% a rendszert leiro diffegyenlet-rendszer
diffegyenlet = @(t,y) [5*log(y(2))*y(1);(1-1.2*y(1))*y(2)];
[tVektor,yMatrix] = ode45(diffegyenlet, params(1:2), params(3:4));
% kirajzolas
abra = figure;
subplot(2, 1, 1);
hold on;
plot(tVektor,yMatrix(:, 1), 'm.-', 'LineWidth', 2);
plot(tVektor,yMatrix(:, 2), 'g:', 'LineWidth', 2);
title('Idobeli lefutasok', 'FontSize', 14);
xlabel('ido', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('ertek', 'FontSize', 12, 'FontWeight', 'bold');
legend('y1','y2');

% fazisgorbe
subplot(2, 1, 2);
plot(yMatrix(:,1), yMatrix(:,2),'r');
title('Fazisgorbe -- allapotter', 'FontSize', 14);
xlabel('y1', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('y2', 'FontSize', 12, 'FontWeight', 'bold');

fid=fopen('gyak8_f83_kimenet.bin','w');
fwrite(fid,tVektor,'double');
fwrite(fid,yMatrix,'double');
fclose(fid);

end