function [cellaTomb, abra]=gyak8_f81_d1jjdq(db)
cellaTomb{1} = linspace(0,2*pi,db);
cellaTomb{2} = {'Sin(3t)', 'Cos(5t)' , 'Sin(3t)*Cos(5t)'};
cellaTomb{3} = {sin(3*cellaTomb{1}),...
    cos(5*cellaTomb{1}) ,...
    sin(3*cellaTomb{1}).*cos(5 * cellaTomb{1})};
abra = figure;
for ind = 1:length(cellaTomb{2})
    subplot(3,1,ind)
    plot(cellaTomb{1},cellaTomb{3}{ind});
    title(cellaTomb{2}{ind});
    xlabel('t');
end
end