function [struktura, abra]=gyak8_f84_d1jjdq(bemenetiFajl)
fs = filesep;
dir_path = ['.', fs];
file_path=[dir_path, bemenetiFajl];
fid = fopen(file_path);
d = fscanf(fid, '%f', [1 6]);
struktura.Z = fscanf(fid, '%f', [21 inf]);
fclose(fid);

[struktura.X, struktura.Y] = meshgrid(d(1):d(2):d(3), d(4):d(5):d(6));
struktura.title='a betoltott adatpont-felho';
struktura.xlabel='x';
struktura.ylabel='y';
struktura.zlabel='z';
abra = figure;
hold on;
grid on;
plot3(struktura.X, struktura.Y, struktura.Z, 'g.');
[struktura.C, struktura.h] = contour3(struktura.X, struktura.Y, struktura.Z);
view(-41, 28);
clabel(struktura.C, struktura.h);
colorbar;
colormap jet;

title(struktura.title, 'FontSize', 14);
xlabel(struktura.xlabel, 'FontSize', 12, 'FontWeight', 'bold');
ylabel(struktura.ylabel, 'FontSize', 12, 'FontWeight', 'bold');
zlabel(struktura.zlabel, 'FontSize', 12, 'FontWeight', 'bold');
end