%% elso fele
p1 = 8/3;
p2 = 28;
p3 = 10;
odefun = @(t,x) [p3*(x(2)-x(1));x(1)*(p2-x(3))-x(2); x(1)*x(2)-p1*x(3)];
tspan=[0 25];
[t y] = ode45(odefun,tspan,[1;1;1]');
figure;
subplot(2,2,1);
plot(t,y(:,1),t,y(:,2),t,y(:,3));
legend('x','y','z')
xlabel('t');
ylabel('allapotvatozo');
title('Lorenz ur az idoben');
subplot(2,2,2);
hold on;
%plot3(y(:,1),y(:,2),y(:,3),'Color',[1-p/25, p/25 p/25]);
for p = 1:25
    indices = t>(p-1)*1 & t <= p*1;
    plot3(y(indices,1),y(indices,2),y(indices,3),'x','Color',[1-p/25, p/25 p/25]);
end

view(15,20);
xlabel('x');
ylabel('y');
xlabel('z');
title('Lorenz ur az allapotterben');

%% masodik fele
x = -5:0.1:5;
[X Y] = meshgrid(x,x);
Z = sin(X).*cos(Y)+X/10-Y/10;
subplot(2,2,3);
surfc(X,Y,Z);
view(-110,30);
xlabel('x');
ylabel('y');
xlabel('z');
title('Sima felulet');

Z(Z>=0 & Z<=1) = 0.5;
subplot(2,2,4);
meshc(X,Y,Z);
view(-110,30);
title('[0, 1] kozotti ertekek 0.5-re allitva');
xlabel('x');
ylabel('y');
xlabel('z');

%% van der pol
vdp = @(t,x) [x(2);-(x(1)^2-1)*x(2)-x(1)];
tspan = [0 20];
[t y] = ode45(vdp,tspan,[0.1,0.1]);
figure
plot(y(:,1),y(:,2));
hold on;
[X Y] = meshgrid(-2:0.1:2,-3:0.1:3);
vx = Y;
vy = -(X.^2-1).*Y-X;
quiver(X,Y,vx,vy);
xlim([-2.1,2.1]);
ylim([-3,3]);
title('van der pol oszcillator allapottere');
xlabel('x');
ylabel('y');

%% MET
domborzat=readtable('domborzat.csv','ReadVariableNames',true);
xlat=reshape(domborzat.xLat,[51,51]);
xlong=reshape(domborzat.xLong,[51,51]);
th=reshape(domborzat.terrainHeight,[51,51]);
surf(xlat,xlong,th)
colormap summer
hold on
load szinek
uvwhgt=readtable('uvwhgt.csv','ReadVariableNames',true);
u=reshape(uvwhgt.u,[51,51,10]);
v=reshape(uvwhgt.v,[51,51,10]);
w=reshape(uvwhgt.w,[51,51,10]);
hgt=reshape(uvwhgt.hgt,[51,51,10]);
for ind=1:10
    quiver3(xlat,xlong,hgt(:,:,ind),u(:,:,ind),v(:,:,ind),w(:,:,ind),0.002,'color',map(ind,:))
end