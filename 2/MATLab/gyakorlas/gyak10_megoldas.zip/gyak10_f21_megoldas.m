function gyak10_f21_megoldas()
% FitzHugh–Nagumo model
% 2-dimensional simplified version of the Hodgkin-Hauxley model
% v is the membrane potential
% w is a recovery variable
% Explanation from Wikipedia
% 2015. 09. 23.
% Ákos Makra: Biomedical Signal Processing lab course
% modified on 2016.05.08. for MATLAB course (midterm2)


% Note, that the goal of parameters here was not to find the natural values
% So you will not see resting potential=-65 mV etc., only the
% charactheristics will resemble to the neuronal process

%I is the magnitude of stimulus current. Try values between -1 and +1.
I = 1;

% PARAMETERS
a=0.7;
b=0.8;
tau=12.5;

tlimit=[0 200];
v0=1;
w0=0.1;

% dv/dt: a voltage-like variable having cubic nonlinearity that allows
%  regenerative self-excitation via a positive feedback
% dw/dt: a recovery variable having a linear dynamics that provides a
%  slower negative feedback
FitzHugh_Nagumo=@(t,vw) [vw(1)-(vw(1)^3)/3-vw(2)+I;(vw(1)+a-b*vw(2))/tau];

[t,vw]=ode45(FitzHugh_Nagumo,tlimit,[v0 w0]);

subplot(3,1,1)
plot(t,vw(:,1));
xlabel('time (s)')
ylabel('potential (V)');
title(strcat('Injected current = ',num2str(I),' nA'));

subplot(3,1,2)
plot(t,vw(:,2));
xlabel('time (s)')
ylabel('potential (V)');
title(strcat('Injected current = ',num2str(I),' nA'));

subplot(3,1,3);
plot(vw(:,1),vw(:,2));
xlabel('Potential (V)')
ylabel('Recovery (mA)');
end