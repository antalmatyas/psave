function gyak10_f32_megoldas()
fid=fopen('riemann.bin');
X=fread(fid,[33,129],'double');
Y=fread(fid,[33,129],'double');
Z=fread(fid,[33,129],'double');
surf(X,Y,Z)
title('Riemann surface','FontSize',22)
set(gca,'FontSize',16)
colorbar
print('riemann.png','-r300','-dpng');
end