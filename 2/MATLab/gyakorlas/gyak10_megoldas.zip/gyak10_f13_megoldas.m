function [atlag,metszespont1,metszespont2,terulet]=gyak10_f13_megoldas()
tartomany=-.1:.01:.38;
P = [3,2.3,-1.1,4];
yP = polyval(P,tartomany);
yX = 4.1*cos(tartomany);
index_vektor = yX>yP;
atlag=mean(yX(index_vektor));
indexek=find(index_vektor);
metszespont1 = min(indexek);
metszespont2 = max(indexek);
terulet=abs(trapz(tartomany(index_vektor),yP(index_vektor))-...
    trapz(tartomany(index_vektor),yX(index_vektor)));
% plot(tartomany,yP,tartomany,yX)
end
