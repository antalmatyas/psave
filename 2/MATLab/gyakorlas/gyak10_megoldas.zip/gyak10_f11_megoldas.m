function gyak10_f11_megoldas()
a = -0.4;
b = 0.1;
c = -0.1;
d = 0.3;
n_r = 0.4;
n_j = 0.6;

R_0 = 2;
J_0 = 3;

x0 = [R_0; J_0];
tspan = [0 100];


Love = @(t,dRdJ) [a*dRdJ(1)+b*dRdJ(2)*(1-n_r*abs(dRdJ(2)));...
    c*dRdJ(1)*(1-n_j*abs(dRdJ(1)))+d*dRdJ(2)];

[t,x]=ode45(Love,tspan,x0);

figure
subplot 211
plot(t,x(:,1))
hold on
plot(t,x(:,2),'r')

legend('Romeo', 'Julia')

subplot 212
plot(x(:,1), x(:,2))
xlabel('R(t)')
ylabel('J(t)')
end