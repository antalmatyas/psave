function gyak10_f12_megoldas()
fid=fopen('felulet.txt');
Z=fscanf(fid,'%f',[50,50]);
% z = textscan(fid,'%f');
% Z = reshape(z,50,50);
[X,Y]=meshgrid(linspace(-4,4,50),linspace(-4,4,50));
[U,V,W]=surfnorm(X,Y,Z);
surf(X,Y,Z);
hold on
quiver3(X,Y,Z,U,V,W);
title('Surface normals','FontSize',22)
xlabel('X','FontSize',20)
ylabel('Y','FontSize',20)
zlabel('Z','FontSize',20)
print('normals.png','-r300','-dpng');
end