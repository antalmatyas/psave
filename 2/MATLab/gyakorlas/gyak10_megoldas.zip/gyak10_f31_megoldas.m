function gyak10_f31_megoldas()
m = 10;
D = 0.2;
K = 0.6;
dp = 5;
a = 4;

% idoablak
tspan=[0 250];

% kezdeti feltetelek ([kiteres; sebesseg])
x0=[1; 0.2];

% ODE megoldasa
[t, x] = ode45(@(t,x) szivhangegyenlet(t, x, m, D, K, dp, a), tspan, x0);



subplot(2,1,1)
plot(t,x(:,1));


hold on
plot(t,x(:,2), 'r');
legend('1', '2')

subplot(3,1,3);
plot(x(:,1),x(:,2));
end