function gyak10_f22_megoldas()
fid=fopen('gabor.txt');
Z=fscanf(fid,'%f',[100,100]);
[X,Y]=meshgrid(linspace(-5,5,100),linspace(-5,5,100));
surf(X,Y,Z)
title('Gabor filter','FontSize',22)
set(gca,'FontSize',16)
xlabel('X','FontSize',20)
ylabel('Y','FontSize',20)
zlabel('Z','FontSize',20)
print('gabor.png','-r300','-dpng');
end