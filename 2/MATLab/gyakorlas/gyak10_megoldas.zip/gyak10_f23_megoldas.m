function [maxErtek,maxIdo,terulet,darabszam]=gyak10_f23_megoldas()
load zh2_alap_02.mat
P3 = polyfit(t,y,3);
P6 = polyfit(t,y,6);
tartomany = 1.1*pi:0.1:3.1*pi;
y3 = polyval(P3,tartomany);
y6 = polyval(P6,tartomany);
plot(tartomany,y3,tartomany,y6)
metszespontok = find(diff(y3>y6));
[maxErtek,maxIndex]=max(y3(metszespontok(3):metszespontok(4)));
maxIdo=tartomany(maxIndex);
terulet=abs(trapz(tartomany(metszespontok(3):metszespontok(4)),...
    y3(metszespontok(3):metszespontok(4)))-...
    trapz(tartomany(metszespontok(3):metszespontok(4)),...
    y6(metszespontok(3):metszespontok(4))));
darabszam=sum(y3>y6);
% plot(tartomany,y3,tartomany,y6)
end