function aramok=gyak4_f44_megoldas(R1,R2,R3,R4,R5,R6,V1,V2,V3)
A=[1 -1 -1;R1+R4+R5 R3 0;0 -R3 R2+R6];
b=[0;-V1-V2;V2+V3];
aramok=A\b;
end