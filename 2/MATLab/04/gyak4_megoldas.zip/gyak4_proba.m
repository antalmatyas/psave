a=[3, 12, 1];b=[12, 0, 2];c=[0, 2, 3];d=[2.36;5.26;2.77];
gyumolcsok_ara=gyak4_f41_megoldas(a,b,c,d);
abra=gyak4_f42_megoldas('house.mat');
a = 7; b = 2; c = 1; d = 8; e = -53; f = 832; g = 428;
[x,y,z]=gyak4_f43_megoldas(a,b,c,d,e,f,g);
aramok=gyak4_f44_megoldas(30,50,20,10,10,10,5,9,12);