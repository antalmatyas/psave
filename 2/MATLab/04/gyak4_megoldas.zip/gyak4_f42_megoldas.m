function abra=gyak4_f42_megoldas(archivum)
% load f�ggv�ny haszn�lata -> l�sd help; fontos, hogy a house.mat
% ugyanabban a mapp�ban legyen, mint a f�ggv�ny, k�l�nben teljes el�r�si
% utat kell adni neki.
load(archivum);

% transzformaciok elvegzese
H1 = kep*A1;
H2 = kep*A2;
H3 = kep*A3;
H4 = kep*A4;

%% Ide ker�lj�n az �bra kirajzoltat�sa
abra = figure; % ez ut�n

subplot(2, 2, 1);
plot(H1(:,1),H1(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A1', 'FontSize', 12, 'FontWeight', 'bold');

subplot(2, 2, 2);
plot(H2(:,1),H2(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A2', 'FontSize', 12, 'FontWeight', 'bold');

subplot(2, 2, 3);
plot(H3(:,1),H3(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A3', 'FontSize', 12, 'FontWeight', 'bold');

subplot(2, 2, 4);
plot(H4(:,1),H4(:,2));
xlim([-10, 10]);
ylim([-10, 10]);
axis equal
title('house*A4', 'FontSize', 12, 'FontWeight', 'bold');
end