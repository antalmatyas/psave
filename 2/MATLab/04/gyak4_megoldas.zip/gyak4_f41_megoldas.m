function gyumolcsok_ara=gyak4_f41_megoldas(a,b,c,d)
A=[a;b;c];
gyumolcsok_ara=A\d;
end