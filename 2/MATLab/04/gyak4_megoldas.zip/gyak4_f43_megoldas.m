function [x,y,z]=gyak4_f43_megoldas(a,b,c,d,e,f,g)
A=[a b 0;c a b;0 b a];
b_=[e;f-d;g+d];
eredmeny=A\b_;
x=eredmeny(1);
y=eredmeny(2);
z=eredmeny(3);
end