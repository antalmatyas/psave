package org.ppke.itk.hj.model;
public enum ProductType {
	
	MOBILE, TABLET, BOOK;
	
}