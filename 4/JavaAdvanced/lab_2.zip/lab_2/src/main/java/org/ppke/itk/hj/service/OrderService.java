package org.ppke.itk.hj.service;

import javax.ejb.Stateless;
import javax.ejb.LocalBean;
import java.io.Serializable;
@Stateless
@LocalBean
public class OrderService implements Serializable {

	private static final long serialVersionUID = -1L;
}