/**
 * 
 */
/**
 * @author bezse
 *
 */
package org.ppke.itk.hj.interfaces;