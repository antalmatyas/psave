package org.ppke.itk.hj.model;

public enum Role {
	
	ADMIN,
	GUEST,
	CUSTOMER;

}
