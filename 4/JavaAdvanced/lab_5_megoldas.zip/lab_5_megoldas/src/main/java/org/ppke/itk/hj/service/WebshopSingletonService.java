package org.ppke.itk.hj.service;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.interceptor.Interceptors;

import org.ppke.itk.hj.util.MethodLogger;

@Singleton
@Startup
@Interceptors({MethodLogger.class})
public class WebshopSingletonService {

	//@Schedule(second="*/20", minute = "*", hour = "*")
    public void logHelloWorld(){
        System.out.println("Hello World!");
    }
}
