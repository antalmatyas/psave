package org.ppke.itk.hj.util;

import java.util.Arrays;

import javax.interceptor.AroundInvoke;
import javax.interceptor.InvocationContext;

public class MethodLogger {
	
	@AroundInvoke
    public Object logMethodInvocation(InvocationContext ic) throws Exception {

		System.out.println("Invoking method: "+ic.getMethod());
	
		System.out.println("Parameters:  "+Arrays.toString(ic.getParameters()));
		
		long startTime = System.currentTimeMillis();
		Object result = ic.proceed();
		long endTime = System.currentTimeMillis() - startTime;
		System.out.println(String.format("Method run duration: %s", endTime));
		return result;
	}

}
