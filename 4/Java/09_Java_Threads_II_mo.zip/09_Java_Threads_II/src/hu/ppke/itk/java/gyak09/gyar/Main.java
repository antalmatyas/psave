package hu.ppke.itk.java.gyak09.gyar;

public class Main {

	public static void main(String[] args) {
		Factory factory = new Factory() ;
		for (int i = 0; i < 10; ++i) {
			new Truck(factory, i).start();
		}
		factory.start() ;
	}
	
}
