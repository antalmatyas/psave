package hu.ppke.itk.java.gyak09.philosophers;

public class Fork {
}
