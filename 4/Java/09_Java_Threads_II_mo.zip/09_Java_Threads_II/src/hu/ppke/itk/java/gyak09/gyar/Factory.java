package hu.ppke.itk.java.gyak09.gyar;

import java.util.LinkedList;
import java.util.Random;

public class Factory extends Thread {

	private LinkedList<Product> products = new LinkedList<>();
	
	@Override
	public void run() {
		Random random = new Random() ;
		for (int i = 0; i < 10; ++i) {
			try {
				Thread.sleep(random.nextInt(4000)+1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("A gyár legyártotta a " + i + ". elemet");
			synchronized (products) {
				products.add(new Product(i)) ;
				products.notify();
				//products.notifyAll();
			}
		}
	}
	
	public Product getProduct(int id) {
		synchronized (products) {
			while (products.size() == 0) {
				try {
					products.wait() ;
					System.out.println("Felébredt az " + id + ". teherautó!");
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			return products.removeFirst();
		}
	}
	
	
}
