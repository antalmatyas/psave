package hu.ppke.itk.java.gyak09.gyar;

public class Truck extends Thread {

	private Factory factory;
	private int id;

	public Truck(Factory factory, int id) {
		this.factory = factory;
		this.id = id;
	}
	
	@Override
	public void run() {
		System.out.println("A " + id + ". teherautó a gyárnál vár...");
		Product product = factory.getProduct(id);
		System.out.println("A " + id + ". teherautóba bepakolták a " + product.getId() + ". terméket.");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("A " + id + ". teherautó elszállította a " + product.getId() + ". terméket.");
	}
}
