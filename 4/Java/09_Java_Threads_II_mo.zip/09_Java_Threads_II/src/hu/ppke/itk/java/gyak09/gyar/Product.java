package hu.ppke.itk.java.gyak09.gyar;

public class Product {

	private int id;

	public Product(int id) {
		this.id = id;
	}
	
	public int getId() {
		return id;
	}
}
