package hu.ppke.itk.java.gyak09.exception_handling;

import java.lang.Thread.UncaughtExceptionHandler;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		Thread roulettThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("Orosz rulett elindítva");
				Random random = new Random() ;
				while (true) {
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					if (random.nextInt(6) == 0) {
						throw new RuntimeException("Meghaltál!");
					} else {
						System.out.println("Szerencséd volt...");
					}					
				}
			}
		});
		roulettThread.setUncaughtExceptionHandler(new UncaughtExceptionHandler() {
			
			@Override
			public void uncaughtException(Thread t, Throwable e) {
				System.out.println("Kivétel történt: " + e.getMessage());
			}
		});
		roulettThread.start();
		
	}
	
}
