package hu.ppke.itk.java.gyak09.philosophers;

public class Philosopher extends Thread {
	
	private Fork left;
	private Fork right;
	private int id;

	public Philosopher(int id, Fork left, Fork right) {
		this.id = id;
		this.left = left;
		this.right = right;
	}
	
	@Override
	public void run() {
		System.out.println(id + ". filozófus megpróbálja felvenni a bal villáját");
		synchronized (left) {
			System.out.println(id + ". filozófus felvette a bal villáját");
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(id + ". filozófus megpróbálja felvenni a jobb villáját");
			synchronized (right) {
				System.out.println(id + ". filozófus felvette a jobb villáját, nekiáll enni");
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out.println(id + ". filozófus megebédelt");
			}
		}
	}

}
