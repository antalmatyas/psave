package layouts;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class BorderPaneStage extends Stage {
  public BorderPaneStage() {
    setTitle("BorderPane");
    BorderPane root = new BorderPane();
    root.setTop(new Button("Top"));
    root.setBottom(new Button("Bottom"));
    root.setRight(new Button("Right"));
    root.setLeft(new Button("Left"));
    root.setCenter(new Button("Center"));
    Scene scene = new Scene(root,200,200);
    setScene(scene);
    show();
  }
}
