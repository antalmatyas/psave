package threading;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class GUI {

  public static void main(String[] args) {
    Stage primaryStage = new Stage();
    Button button = new Button("Calculate!");
    button.setFont(Font.font(20));
    primaryStage.setTitle("JavaFX concurrency demo");
    primaryStage.setScene(new Scene(button));
    primaryStage.setOnCloseRequest(event -> System.exit(0));
    button.setOnAction(new PiCalculation(button));
    primaryStage.show();
  }
}
