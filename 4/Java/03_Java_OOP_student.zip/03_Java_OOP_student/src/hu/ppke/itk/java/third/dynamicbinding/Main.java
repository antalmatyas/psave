package hu.ppke.itk.java.third.dynamicbinding;

import hu.ppke.itk.java.third.vehicles.*;

public class Main {

	/**
	 * dinamikus kötés, statikus, dinamikus típus bemutatása
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		try {
			Car a = new Car("Subaru", 10, 4, 0);
			Car b = new Taxi("Honda", 5, 5, 300);
			System.out.println(a.toString());
			System.out.println(b.toString());
			a.refuel(20);
			a.go(100);
			System.out.println(a.toString());
			b.refuel(20);
			b.go(100);
			System.out.println(b.toString());
			if (b instanceof Taxi) {
				Taxi c = (Taxi) b;
				System.out.println("Taxival fuvarozunk 100 km-t:");
				c.transfer(100);
			}
			System.out.println(b.toString());
			System.out.println("");
			Vehicle[] temp = new Vehicle[4];
			temp[0] = a;
			temp[1] = b;
			temp[2] = new Bicycle("Magellan");
			temp[3] = new Bus("Ikarus", 15, 30, 200);
			for (Vehicle j : temp) {
				System.out.println(j.toString());
				j.go(10);
				System.out.println(j.toString());
				System.out.println("");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
