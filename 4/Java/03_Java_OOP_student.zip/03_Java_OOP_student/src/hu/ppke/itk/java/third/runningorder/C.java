package hu.ppke.itk.java.third.runningorder;

public class C extends B {
	
	static
	{
		System.out.println("C osztály static inicializáló blokkja lefutott.");
	}
	
	{
		System.out.println("C osztály példány inicializáló blokkja lefutott.");
	}
	
	C(){
		System.out.println("C konstruktora lefutott.");
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		C c = new C();
	}

}
