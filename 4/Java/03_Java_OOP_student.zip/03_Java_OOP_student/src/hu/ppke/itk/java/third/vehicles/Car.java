package hu.ppke.itk.java.third.vehicles;

/**
 * Auto osztály benzin ár, típus, kmóra, fogyasztás és férőhely adatagokkal
 * 
 * @author divad, sonil
 */
public class Car {

	// osztály szintű változók

	static protected int fuelPrice = 400; // statikus változó

	// példány szintű változók

	protected double fuel = 0;
	protected double consumption;
	protected String type;
	protected double km;
	protected int capacity;

	// konstruktorok

	/**
	 * @param type
	 *            az autó típusa
	 * @param consumption
	 *            km-enkénti fogyasztás
	 * @param ferohely
	 *            ülőhelyek száma
	 */
	public Car(String type, double consumption, int capacity) {
		this.type = type;
		this.consumption = consumption;
		this.capacity = capacity;
		km = 0;
	}

	/**
	 * @param type
	 *            az autó típusa
	 * @param consumption
	 *            km-enkénti fogyasztás
	 * @param capacity
	 *            ülőhelyek száma
	 * @param km
	 *            edddig megtett km-ek
	 */
	public Car(String type, double consumption, int capacity, double km) {
		this.type = type;
		this.consumption = consumption;
		this.km = km;
		this.capacity = capacity;
	}

	/**
	 * @param type
	 *            az autó típusa
	 * @param capacity
	 *            ülőhelyek száma
	 */
	public Car(String type, int capacity) {
		this(type, 10, capacity);
	}

	// példány szintű metódusok: getterek

	/**
	 * @return benzin
	 */
	public double getFuel() {
		return fuel;
	}

	/**
	 * @return km óra
	 */
	public double getKm() {
		return km;
	}

	// egyéb példány szintű metódusok

	/**
	 * @param liter
	 *            benzin adattag növelése a paraméterben megadott mennyiséggel
	 */
	public void refuel(double liter) {
		fuel += liter;
	}

	/**
	 * @param km
	 * @return a megadott km megtételéhez szükséges benzin mennyisége
	 */
	protected final double fuelNeed(double km) {
		return (km / 100) * consumption;
	}

	/**
	 * @param km
	 * @return adott km megtételéhez elegendő benzin koltsege
	 */
	public double cost(double km) {
		return fuelNeed(km) * fuelPrice;
	}

	/**
	 * @param km
	 * @return ténylegesen megtett kilométer
	 */
	public final double go(double km) {
		if (fuelNeed(km) <= fuel) {
			fuel -= fuelNeed(km);
			this.km += km;
			System.out.println("Megtettünk " + km + " km utat!");
			return km;
		} else {
			System.out.println("Nincs elég benzin " + km + " km úthoz!");
			return 0;
		}
	}

	/**
	 * @return Az objektum String reprezentációja
	 */
	@Override
	public String toString() {
		return type + ", benzin: " + getFuel() + ", km: " + getKm() + ", férőhely: " + capacity;
	}

	/**
	 * main függvény
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Car car = new Car("Subaru", 2.3, 5, 100.57);
		System.out.println("Az autónk: " + car);
		System.out.println("100 km-ert szeretnenk haladni.");
		System.out.println("Elmegyünk tankolni. Tankolunk 10 litert.");
		car.refuel(10);
		System.out.println("Végül elindulunk.");
		car.go(100);
	}
}
