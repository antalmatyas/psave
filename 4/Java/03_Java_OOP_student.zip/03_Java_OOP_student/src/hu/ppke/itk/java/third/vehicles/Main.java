package hu.ppke.itk.java.third.vehicles;

/**
 * Járművek működésének tsztelésére szolgáló osztály
 * 
 * @author sonil, divad
 */
public class Main {

	/**
	 * Autó és Taxi osztályok tesztelése, működése
	 * 
	 * @param args
	 * 
	 */
	public static void main(String[] args) {
		try {
			// autó
			Car lada = new Car("Lada", 10, 5);
			System.out.println(lada.toString());

			System.out.println("Tankolunk az autóval 40 litert.");
			lada.refuel(40);
			System.out.println("Megteszünk az autóval 15 km-t.");
			lada.go(15);
			System.out.println(lada.toString());
			System.out.println("");

			/*
			// taxi
			Taxi daewoo = new Taxi("Daewoo", 7, 5, 200);
			System.out.println(daewoo.toString());

			System.out.println("Tankolunk a taxival 30 litert.");
			daewoo.refuel(30);
			System.out.println("Megteszünk a taxival 15 km-t.");
			daewoo.go(15);
			System.out
					.println("Ennyibe kerülne, ha 4-en mennénk a Taxival 200 km-ert: "
							+ daewoo.costPerPerson(200, 4)); // 815.625
			System.out.println("Taxi fuvaroz 200 km-t.");
			daewoo.transfer(200);
			System.out.println(daewoo.toString());
			System.out.println("");

			// busz
			Bus ikarus = new Bus("Ikarus", 7, 30, 100);
			System.out.println(ikarus.toString());
			System.out.println("Jegy ára: " + Bus.getTicketPrice());
			System.out.println("Tankolunk a busszal 10 litert.");
			ikarus.refuel(10);
			System.out.println("Utazunk 30-an 1 km-t.");
			ikarus.transfer(1, 30);
			System.out.println(ikarus.toString());
			System.out.println("");

			// bicikli
			Bicycle mountainBike = new Bicycle("Mountain Bike");
			System.out.println(mountainBike.toString());
			mountainBike.go(120);
			System.out.println(mountainBike.toString());
			*/
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

}
