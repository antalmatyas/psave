package hu.itk.ppke.lesson5.collections.mapTest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * 
 * Osztály a különböző Map implementációk sebességkülönbségének vizsgálatára.
 * 
 */
public class MapTest {

	private static final int ELEMENT_COUNT = 1000000; //  = 10; a sorrend megfigyeléséhez
	
	private static final List<Integer> RANDOM_NUMBERS = new ArrayList<>();
	
	static {
		Random random = new Random();
		for (int i = 0; i < ELEMENT_COUNT; ++i) {
			Integer randInt = random.nextInt();
			RANDOM_NUMBERS.add(randInt);
		}
	}
	
	public static void main(String[] args) {
		Map<Integer, String> hashMap = new HashMap<Integer, String>();
		Map<Integer, String> treeMap = new TreeMap<Integer, String>();
		Map<Integer, String> linkedHashMap = new LinkedHashMap<Integer, String>();

		// Feladat: töltsd fel a fenti adatszerkezeteket random kulcs-érték
		// párokkal (mondjuk 1-10 millió elemmel) és teszteld le a feltöltés
		// sebességét
		populateMap(hashMap);
		populateMap(linkedHashMap);
		populateMap(treeMap);
		
		// Feladat: teszteld le a kulcs alapján történő keresés sebességét
		testGetByKey(hashMap);
		testGetByKey(linkedHashMap);
		testGetByKey(treeMap);
		
		// Feladat: teszteld le a bejárásokat, figyeld meg a sorrendezést!
		testIteration(hashMap);
		testIteration(linkedHashMap);
		testIteration(treeMap);
	}
	
	private static void populateMap(Map<Integer, String> map) {
		long start = startCounter(map, "feltöltése");
		
		for (Integer randInt : RANDOM_NUMBERS) {
			map.put(randInt, Integer.toString(randInt));
		}
		
		printTime(start);
	}
	
	private static void testGetByKey(Map<Integer, String> map) {
		long start = startCounter(map, "lekérés kulcs alapján");
		
		for (Integer randInt : RANDOM_NUMBERS) {
			map.get(randInt);
		}
		
		printTime(start);
	}
	
	private static void testIteration(Map<Integer, String> map) {
		long start = startCounter(map, "iterálás");
		
		for (@SuppressWarnings("unused") Map.Entry<Integer, String> e : map.entrySet()) {
			// System.out.println(e.getKey()); // kevés elem esetén kiírhatjuk a sorrend megfigyeléséhez
		}
		
		printTime(start);
	}
	
	private static long startCounter(Map<Integer, String> map, String message) {
		System.out.println(map.getClass().getSimpleName() + " " + message);
		return System.currentTimeMillis();
	}
	
	private static void printTime(long start) {
		System.out.println("idő: " + (System.currentTimeMillis() - start));
	}
}
