package hu.itk.ppke.lesson5.collections.collectionTest;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 * Osztály a különböző List implementációk sebességéne összehasonlítására.
 * 
 */
public class CollectionsTest {

	private static final int ELEMENT_COUNT = 1000000;

	public static void main(String[] args) {
		List<Integer> arrayList = new ArrayList<Integer>();
		List<Integer> linkedList = new LinkedList<Integer>();

		// Feladat: feltöltések összehasonlítása - töltsük fel mindegyik listán
		// 100000-1000000 elemmel
		populateList(arrayList);
		populateList(linkedList);

		// Feladat: index alapján történő lekérések sebességének
		// összehasonlítása
		testGetIndex(arrayList);
		testGetIndex(linkedList);

		// Feladat: iterálások sebességének mérése
		testIteration(arrayList);
		testIteration(linkedList);
	}

	private static void populateList(List<Integer> list) {
		long start = startCounter(list, " feltöltése");

		for (int i = 0; i < ELEMENT_COUNT; ++i) {
			list.add(i);
		}

		printTime(start);
	}

	private static void testGetIndex(List<Integer> list) {
		long start = startCounter(list, "lekérés index alapján");

		for (int i = 0; i < ELEMENT_COUNT / 10; ++i) {
			list.get(i);
		}

		printTime(start);
	}

	private static void testIteration(List<Integer> list) {
		long start = startCounter(list, "iterálás");

		for (@SuppressWarnings("unused")
		Integer integer : list) {

		}

		printTime(start);
	}

	private static long startCounter(List<Integer> list, String message) {
		System.out.println(list.getClass().getSimpleName() + " " + message);
		return System.currentTimeMillis();
	}

	private static void printTime(long start) {
		System.out.println("idő: " + (System.currentTimeMillis() - start));
	}
}
