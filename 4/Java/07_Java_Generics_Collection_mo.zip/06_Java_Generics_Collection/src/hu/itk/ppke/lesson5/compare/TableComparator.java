package hu.itk.ppke.lesson5.compare;

import java.util.Comparator;

/**
 * Két {@link Table}-t összehasonlítani képes {@link Comparator} osztály.
 * 
 * @author Kozak Csaba
 */
public class TableComparator implements Comparator<Table> {

	@Override
	public int compare(Table o1, Table o2) {
		if (o1.getNumberOfLegs() < o2.getNumberOfLegs()) {
			return -1;
		} else if (o1.getNumberOfLegs() == o2.getNumberOfLegs()) {
			return 0;
		} else {
			return 1;
		}

		// egyszerűbben:
		// return Integer.compare(o1.getNumberOfLegs(), o2.getNumberOfLegs());

	}

}
