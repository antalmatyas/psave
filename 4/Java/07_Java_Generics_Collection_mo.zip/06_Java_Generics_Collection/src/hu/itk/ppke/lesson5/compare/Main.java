package hu.itk.ppke.lesson5.compare;

import java.util.Collections;
import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		Table t1 = new Table(4);
		Table t2 = new Table(3);
		Table t3 = new Table(10);
		LinkedList<Table> l = new LinkedList<Table>();
		l.add(t1);
		l.add(t2);
		l.add(t3);
		System.out.println("rendezés előtt:\t" + l);
		 Collections.sort(l, new TableComparator());
		//Alternatív megoldás: rendezés lambda operátorral:
		 Collections.sort(l, (o1,o2)->Integer.compare(o1.getNumberOfLegs(), o2.getNumberOfLegs()));
		 
		System.out.println("rendezés után:\t" + l);

		ComparableTable ct1 = new ComparableTable(4);
		ComparableTable ct2 = new ComparableTable(3);
		ComparableTable ct3 = new ComparableTable(10);
		LinkedList<ComparableTable> ll = new LinkedList<ComparableTable>();
		ll.add(ct1);
		ll.add(ct2);
		ll.add(ct3);
		System.out.println("rendezés előtt:\t" + ll);
		Collections.sort(ll);
		System.out.println("rendezés után:\t" + ll);
	}
}
