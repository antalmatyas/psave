package hu.itk.ppke.lesson5.collections.mapTest;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 
 * Osztály a különböző Map implementációk sebességkülönbségének vizsgálatára.
 * 
 */
public class MapTest {

	public static void main(String[] args) {
		Map<Integer, String> hashMap = new HashMap<Integer, String>();
		Map<Integer, String> treeMap = new TreeMap<Integer, String>();
		Map<Integer, String> linkedHashMap = new LinkedHashMap<Integer, String>();

		// Feladat: töltsd fel a fenti adatszerkezeteket random kulcs-érték
		// párokkal (mondjuk 1-10 millió elemmel) és teszteld le a feltöltés
		// sebességét
		// Feladat: teszteld le a kulcs alapján történő keresés sebességét
		// Feladat: teszteld le a bejárásokat, figyeld meg a sorrendezést!

	}
}
