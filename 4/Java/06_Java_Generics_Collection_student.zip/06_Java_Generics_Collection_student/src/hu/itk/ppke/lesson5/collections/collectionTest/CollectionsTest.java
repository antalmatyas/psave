package hu.itk.ppke.lesson5.collections.collectionTest;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 * Osztály a különböző List implementációk sebességéne összehasonlítására.
 * 
 */
public class CollectionsTest {
	public static void main(String[] args) {
		List<Integer> arrayList 	= new ArrayList<Integer>();
		List<Integer> linkedList 	= new LinkedList<Integer>();
		// List<Integer> yourList = new ...; - az első feladat a saját lista
		// implementációd elkészítése

		// Feladat: feltöltések összehasonlítása - töltsük fel mindegyik listán
		// 100000-1000000 elemmel
		long start = System.currentTimeMillis();
		// execution
		System.out.println(System.currentTimeMillis() - start);

		// Feladat: index alapján történő lekérések sebességének
		// összehasonlítása
		// Feladat: iterálások sebességének mérése
	}
}
