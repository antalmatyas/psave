package hu.ppke.itk.java.eighth.epicjoketeller;

import java.net.ServerSocket;
import java.net.Socket;

import java.io.IOException;

public class JokeServer implements Runnable {
	public static final int PORT_NUMBER = 10143;

	public JokeServer() throws IOException {
		serverSocket = new ServerSocket(PORT_NUMBER);
	}

	public void close() throws IOException {
		serverSocket.close();
	}

	public void run() {
		try {
			while (! Thread.currentThread().isInterrupted()) {
				Socket clientSocket = serverSocket.accept();
				try {
					new EpicJokeTeller(clientSocket).start();
				} catch (IOException e) {
					System.err.println("Failed to communicate with client!");
				}
			}
		} catch (IOException e) {
			System.out.println("Accept failed!");
		}

		try {
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		try {
			new Thread(new JokeServer()).start();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	protected ServerSocket serverSocket;
}
