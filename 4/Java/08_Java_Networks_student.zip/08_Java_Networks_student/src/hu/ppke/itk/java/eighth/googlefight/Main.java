package hu.ppke.itk.java.eighth.googlefight;

import java.io.*;

public class Main {

	/**
	 * Mérhetetlenül egyszerű példaprogram a googleFight problémára. Csak
	 * egyszavas keresőkifejezéseket kezel!
	 * 
	 * @param args
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		
		GoogleFight myFighter = new GoogleFight();
		BufferedReader stdIn = new BufferedReader(new InputStreamReader(
				System.in));

		System.out.println("Szeretnel újabb GoogleFight-ot? ");
		while (!stdIn.readLine().equals("nem")) {
			myFighter.setStrings();
			myFighter.fight();
			System.out.println("Szeretnel újabb GoogleFight-ot? ");
		}
		System.out.println("Viszlát.");
	}

}
