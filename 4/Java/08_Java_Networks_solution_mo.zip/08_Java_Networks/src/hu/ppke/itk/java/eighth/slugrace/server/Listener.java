package hu.ppke.itk.java.eighth.slugrace.server;

import java.io.IOException;
import java.net.*;

public class Listener extends Thread {
	@Override
	public void run() {
		try {
			ServerSocket serverSocket = new ServerSocket(12345);
			serverSocket.setSoTimeout(50);
			
			while (!interrupted()) {
				try {
					Socket clientSocket = serverSocket.accept();
					new Client(clientSocket).start();
				} catch (SocketTimeoutException e) {
				}
			}
			
			serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
