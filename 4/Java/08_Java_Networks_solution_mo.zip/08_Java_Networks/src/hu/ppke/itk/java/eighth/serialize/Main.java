package hu.ppke.itk.java.eighth.serialize;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

public class Main {

	public static void main(String[] args) {
		HashMap<String, String> map = new HashMap<>();
		map.put("Alma", "piros");
		map.put("Körte", "zöld");

		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("map.dat"));

		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("map.dat"));)

		{
			oos.writeObject(map);

			@SuppressWarnings("unchecked")
			Object deserialized = (HashMap<String, String>) ois.readObject();

			System.out.println(deserialized);

		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
