package hu.ppke.itk.java.eighth.googlefight;

import java.io.*;
import java.net.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Google-fight-ot megvalósítő osztály
 * @author rudanj
 *
 */
public class GoogleFight {
	private String fighter1, fighter2, googleSearch="http://www.google.com/search?hl=en&q=";
	private BufferedReader stdIn = new BufferedReader(new InputStreamReader(System.in));
	
	/**
	 * alapértelmezett fight
	 */
	public GoogleFight()
	{
		// állítsuk a fighter1 és fighter2 stringeket kedvenc alapértékünkre
		
		fighter1 = "C++";
		fighter2 = "Java";
		
		// aztán indul a verseny
		fight();
	}
	
	/**
	 * fight indítása
	 */
	public void fight()
	{
		System.out.println("A talalatok szama a '" + fighter1 + "' szora: " + numOfResults(fighter1));
		System.out.println("A talalatok szama a '" + fighter2 + "' szora: " + numOfResults(fighter2));
	}
	
	/**
	 * Keresőkifejezések megadása
	 */
	public void setStrings()
	{
		try
		{
			// kérjük be a 2 versenyző stringet, és tároljuk el a fighter1 és fighter2-ben
			System.out.println("Kérem az első keresőszót:");
			fighter1 = stdIn.readLine();
			System.out.println("Kérem a második keresőszót:");
			fighter2 = stdIn.readLine();
		}
		catch(IOException e){e.printStackTrace();}
	}
	
	/**
	 * Találatok számának meghatározása
	 * @param fighter - a keresőszavak megfelelő formátumú kombinációja
	 * @return
	 */
	public String numOfResults(String fighter)
	{
		try
		{
			URL myUrl=new URL(googleSearch + fighter);
			
			// hozzuk létre a gConn elnevezésú ULRConnection-t
			// majd a myUrl változó segítségével inicializáljuk
			
			URLConnection gConn = myUrl.openConnection();

			gConn.addRequestProperty("User-Agent", "powa user"); //ez azert kell, hogy ne tudja mr. google, hogy egy progi hasznalja a search engine-t. (ugyanis alapbol valami javaClient szeruseg lenne)
			
			// vegyuk át a gConn input stream-ját, és pakoljuk egy BufferedReader-be
			
			InputStream stream = gConn.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(stream));

			String fullText="", inputLine;
			while ((inputLine = in.readLine()) != null) {
				fullText+=inputLine;
			}
			in.close();
			
			Pattern pattern = Pattern.compile("About (([0-9]|,)*)");
			Matcher matcher = pattern.matcher(fullText);
			
			String result = null;
			
			if(matcher.find()) {
			    result = matcher.group(1);    
			}
			
			return result;
		}
		catch (MalformedURLException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return "Ha ez megy vissza, akkor valszeg tobb szobol raktak ossze az url-t. Azt kulon le kell kezelni.";
	}

}
