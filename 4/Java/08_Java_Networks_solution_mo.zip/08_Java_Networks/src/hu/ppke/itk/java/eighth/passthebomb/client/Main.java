package hu.ppke.itk.java.eighth.passthebomb.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class Main {

	public static void main(String[] args) {

		try (Socket socket = new Socket(InetAddress.getLocalHost(), 12345);
		     BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));) {
			new Receiver(socket).start();
			
			PrintWriter sout = new PrintWriter(socket.getOutputStream());
			
			String line;
			while ((line = cin.readLine()) != null) {
				if (line.equals("PASSTHEBOMB")) {
					sout.print(line + "\r\n");
					sout.flush();
				} else if (line.equals("QUIT"))
					break;
			}
				
			
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
