package hu.ppke.itk.java.eighth.slugrace.server;

import java.io.*;
import java.net.*;

public class Manager {
	private int[] left;
	
	public Manager() {
		this.left = new int[Client.numberOfClients];
		for (int i=0; i<left.length; i++) {
			left[i] = 6;
		}
		
		StringBuilder builder = new StringBuilder();
		for (int l : left) {
			builder.append(' ').append(l);
		}
		String message = builder.toString();
		for (Socket s : Client.clients) {
			try {
				OutputStream out = s.getOutputStream();
				out.write(message.getBytes());
				out.write('\r');
				out.write('\n');
				out.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	synchronized void step(int id) {
		
		if(left[id] > 0)
			left[id]--;
		
		StringBuilder builder = new StringBuilder();
		for (int l : left) {
			builder.append(' ').append(l);
		}
		String message = builder.toString();
		for (Socket s : Client.clients) {
			try {
				OutputStream out = s.getOutputStream();
				out.write(message.getBytes());
				out.write('\r');
				out.write('\n');
				out.flush();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		boolean end = true;
		for (int l : left) {
			if (l > 0) {
				end = false;
			}
		}
		if (end) {
			for (Socket s : Client.clients) {
				try {
					OutputStream out = s.getOutputStream();
					out.write("GAME OVER\r\n".getBytes());
					out.flush();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
