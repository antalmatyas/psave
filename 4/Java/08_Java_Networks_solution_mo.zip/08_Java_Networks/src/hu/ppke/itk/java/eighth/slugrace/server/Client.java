package hu.ppke.itk.java.eighth.slugrace.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;
import java.util.*;

public class Client extends Thread {
	static int numberOfClients = 0;
	static List<Socket> clients = new LinkedList<Socket>();
	
	private Socket socket;
	private int id;

	public Client(Socket socket) {
		this.socket = socket;
		this.id = numberOfClients++;
		clients.add(socket);
	}
	
	@Override
	public void run() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String line;
			while ((line = in.readLine()) != null) {
				if (line.equals("GOGOGO")) {
					if (Main.manager != null) {
						Main.manager.step(id);
					}
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				// ignore
			}
		}
	}
}
