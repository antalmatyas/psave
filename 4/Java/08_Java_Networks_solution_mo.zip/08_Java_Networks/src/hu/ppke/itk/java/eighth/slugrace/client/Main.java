package hu.ppke.itk.java.eighth.slugrace.client;

import java.io.*;
import java.net.*;

public class Main {
	public static void main(String[] args) {
		try (Socket socket = new Socket(InetAddress.getLocalHost(), 12345);
			BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));) {
			new Receiver(socket).start();

			PrintWriter sout = new PrintWriter(socket.getOutputStream());
			String line;
			while ((line = cin.readLine()) != null) {
				if (line.equals("GOGOGO")) {
					sout.print("GOGOGO\r\n");
					sout.flush();
				}
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
