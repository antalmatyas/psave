package hu.ppke.itk.java.eighth.passthebomb.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.LinkedList;
import java.util.List;

public class Client extends Thread {
	
	static List<Client> clients = new LinkedList<>();
	
	private Socket socket;
	private Bomb bomb;
	private volatile boolean running = true;

	public Client(Socket socket) {
		this.socket = socket;
		clients.add(this);
		setName("Client " + clients.size());
	}
	
	@Override
	public void run() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String line;
			while (running && (line = in.readLine()) != null) {
				if (line.equals("PASSTHEBOMB")) {
					if(hasBomb()) {
						removeBomb();
						Main.manager.passTheBomb();
					}
						
				}
			}
		} catch (IOException e) {
			
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				// ignore
			}
		}
	}
	
	public void addBomb(Bomb bomb) {
		this.bomb = bomb;
		bomb.start();
	}
	
	public void removeBomb() {
		bomb.terminate();
		bomb = null;
	}
	
	public boolean hasBomb() {
		return bomb != null;
	}
	
	public void send(String s) throws IOException {
		OutputStream os = socket.getOutputStream();
		os.write(s.getBytes());
		os.write('\r');
		os.write('\n');
		os.flush();
	}
	
	public void terminate() {
		try {
			socket.close();
			running = false;
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
