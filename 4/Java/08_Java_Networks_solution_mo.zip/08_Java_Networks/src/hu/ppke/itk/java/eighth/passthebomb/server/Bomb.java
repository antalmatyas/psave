package hu.ppke.itk.java.eighth.passthebomb.server;

public class Bomb extends Thread {
	
	private int left;
	private volatile boolean running = true;
	
	public Bomb(int startTime) {
		left = startTime;
		setName("Bomb");
	}
	
	public void terminate() {
		running = false;
	}
	
	@Override
	public void run() {
		while (running) {
			try {
				sleep(1000);
				left--;
				
				if(left <= 0 && running) {
					Main.manager.finishGame();
					break;
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
