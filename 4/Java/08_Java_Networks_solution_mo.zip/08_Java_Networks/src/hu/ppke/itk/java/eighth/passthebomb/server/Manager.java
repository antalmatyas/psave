package hu.ppke.itk.java.eighth.passthebomb.server;

import java.io.IOException;
import java.util.Random;

public class Manager {
	
	private static Random random = new Random();
	
	public Manager() {
		passTheBomb();
	}
	
	public void passTheBomb() {
		int newId = random.nextInt(Client.clients.size());
		Client newClient = 	Client.clients.get(newId);
		Bomb bomb = new Bomb(random.nextInt(20));
		newClient.addBomb(bomb);
		try {
			newClient.send("You have the bomb!");
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	public void finishGame() {
		for(Client c : Client.clients) {
			try {
				if (c.hasBomb())
					c.send("YOU LOSE!");
				c.send("GAME OVER!");
				c.terminate();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}
}
