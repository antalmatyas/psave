package hu.ppke.itk.java.eighth.passthebomb.server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
	static Manager manager;

	public static void main(String[] args) throws IOException, InterruptedException {
		Thread listener = new Listener();
		listener.start();
		
		BufferedReader cin = new BufferedReader(new InputStreamReader(System.in));
		while (!cin.readLine().equalsIgnoreCase("START"));
		listener.interrupt();
		cin.close();
		
		listener.join();
		manager = new Manager();
	}

}
