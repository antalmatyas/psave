package hu.ppke.itk.java.second.practice;
/**
 * Adottak az a.txt és a b.txt fáljok fésüljük őket össze a c.txt fájlba
 * úgy hogy felváltva olvasunk belőlük! 
 * Figyeljünk arra mi van akkor ha az egyik fájlban már nincs több adat
 * de a másikban még van illetve ha az egyik fájl esetleg üres!
 * @author Laki András
 */
public class Merge {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
}
