package hu.ppke.itk.java.fourth.interfaces.demo;

import hu.ppke.itk.java.fourth.interfaces.ChildInterface;
import hu.ppke.itk.java.fourth.interfaces.Marker;
import hu.ppke.itk.java.fourth.interfaces.ParentInterfaceTwo;

public class Demo implements ChildInterface, Marker {

	public static void main(String[] args) {
		Demo demo = new Demo();
		demo.defaultMethod();

		System.out.println(Demo.NAME);

		ChildInterface.staticMethod();
		ParentInterfaceTwo.staticParentMethod();

		@SuppressWarnings("unused")
		Marker marker = demo;
	}

}
