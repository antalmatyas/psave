package hu.ppke.itk.java.fourth.innerclasses.demo;

import hu.ppke.itk.java.fourth.innerclasses.Outer;
import hu.ppke.itk.java.fourth.innerclasses.Outer.Inner2;
import hu.ppke.itk.java.fourth.innerclasses.Outer.StaticInner;

public class Demo {

	public static void main(String[] args) {
		Outer outer = new Outer();
		System.out.println(outer);

		// Az Inner1 classot itt nem érjük el

		// Az Inner2 példányt csak egy Outer példányon keresztül tudjuk példányosítani!
		Inner2 inner2 = outer.new Inner2();
		System.out.println(inner2);

		// A StaticInner mivel nem függ az Outer osztálytól ezért egyszerűen példányosítható.
		StaticInner staticInner = new StaticInner();
		System.out.println(staticInner);

		// Anonymous inner class példa:
		System.out.println("The anonymous InnerInterface's result: " + new Outer.InnerInterface() {

			@Override
			public double getResult() {
				return Math.random() * 100;
			}
		}.getResult());
	}

}
