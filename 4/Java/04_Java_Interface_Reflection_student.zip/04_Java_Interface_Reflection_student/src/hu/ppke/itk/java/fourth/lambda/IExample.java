package hu.ppke.itk.java.fourth.lambda;

public interface IExample {
	
	int getResult(int x);

}
