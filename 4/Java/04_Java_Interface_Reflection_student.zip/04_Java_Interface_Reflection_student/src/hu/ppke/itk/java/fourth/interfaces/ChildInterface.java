package hu.ppke.itk.java.fourth.interfaces;

public interface ChildInterface extends ParentInterfaceOne, ParentInterfaceTwo {

	String NAME = ChildInterface.class.getSimpleName();

	// Példa egy azonos nevű konstans felüldefiniálására. 
	int SAME_NAME_CONSTANT = ParentInterfaceOne.SAME_NAME_CONSTANT;

	// @Override
//	 public void defaultMethod();

//	 void defaultMethod();

	@Override
	default void defaultMethod() {
		ParentInterfaceTwo.super.defaultMethod();
	}

	static void staticMethod() {
		System.out.println(ChildInterface.class.getSimpleName() + ".staticMethod()");
	}

}
