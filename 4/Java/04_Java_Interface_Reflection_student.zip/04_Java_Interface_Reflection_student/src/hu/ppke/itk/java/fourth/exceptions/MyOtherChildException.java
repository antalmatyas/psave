package hu.ppke.itk.java.fourth.exceptions;

public class MyOtherChildException extends MyParentException {
	private static final long serialVersionUID = 1L;
	
	public String getMessage(){
		return "It's an other child";
	}
}
