package hu.ppke.itk.java.fourth.interfaces;

public interface ParentInterfaceTwo {

	String NAME = ParentInterfaceTwo.class.getSimpleName();
	
	int SAME_NAME_CONSTANT = 10;

	default void defaultMethod() {
		System.out.println(NAME+"."+"defaultMethod()");
	}
	
	static void staticParentMethod() {
		System.out.println(ParentInterfaceTwo.class.getSimpleName() + ".staticParentMethod()");
	}

}
