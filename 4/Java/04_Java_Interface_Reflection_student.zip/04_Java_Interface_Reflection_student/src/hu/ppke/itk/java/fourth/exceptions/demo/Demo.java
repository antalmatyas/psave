package hu.ppke.itk.java.fourth.exceptions.demo;

import java.io.IOException;

import hu.ppke.itk.java.fourth.exceptions.MyChildException;
import hu.ppke.itk.java.fourth.exceptions.MyOtherChildException;
import hu.ppke.itk.java.fourth.exceptions.MyParentException;

public class Demo {

	/**
	 * Futtassuk ezt az alkalmazást többször Eclipse-ben!
	 * Nézzük meg a kiíratások sorrendjét!
	 */
	public static void main(String[] args) {
		try {
			thrower();
		} catch (MyParentException e){
			System.out.println("Én most egy szülőt kaptam el.");
			System.err.println(e.getMessage());
		} finally {
			System.out.println("Ez mindig lefut.");
		}
		
		try {
			boolean first = true;
			if (first){
				throw new MyOtherChildException();
			} else {
				throw new MyChildException();
			}
		} catch (MyChildException e){
			System.out.println("Elkaptam a MyChildException-t");
		} catch (MyParentException e){
			System.err.println(e.getMessage());
		} finally {
			System.out.println("Ez is lefut.");
		}
		
		try{
			Integer a = System.in.read();
			throw new RuntimeException(); //Ellenőrizetlen kivétel
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			System.out.println("Ez akkor is lefut, ha elszáll a program.");
		}
	}
	
	public static void thrower() throws MyChildException{
		throw new MyChildException();
	}

}
