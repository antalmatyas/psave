package hu.ppke.itk.java.fourth.interfaces;

public interface ParentInterfaceOne {
	
	String NAME = ParentInterfaceOne.class.getSimpleName();

	int SAME_NAME_CONSTANT = 1000;
	
	public abstract void defaultMethod();

}
