package hu.ppke.itk.java.fourth.interfaces;

public interface Marker {

}
