package hu.ppke.itk.java.fourth.exceptions;

public class MyParentException extends Exception {
	private static final long serialVersionUID = 1L;

	public String getMessage(){
		return "It's the parent";
	}
}
