package hu.ppke.itk.java.fourth.exceptions;

public class MyChildException extends MyParentException {
	private static final long serialVersionUID = 1L;
	
	public String getMessage(){
		return "It's a child";
	}
}
