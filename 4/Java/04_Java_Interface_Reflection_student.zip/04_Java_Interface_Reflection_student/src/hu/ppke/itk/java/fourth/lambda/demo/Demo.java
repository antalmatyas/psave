package hu.ppke.itk.java.fourth.lambda.demo;

import hu.ppke.itk.java.fourth.lambda.IExample;

public class Demo {

	public static void main(String[] args) {
		int[] array = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9 };

		IExample ie = (x) -> x * x;
		// IExample ie = (int x) -> { return x * x; };

		for (int i = 0; i < array.length; i++) {
			int result = ie.getResult(array[i]);
			System.out.println("The result for " + array[i] + " is " + result);
		}

		System.out.println();
		System.out.println();
		
		int[] results = createArrayWithResults(array, (x) -> x * 100);
		for (int i = 0; i < array.length; i++) {
			System.out.println("The result for " + array[i] + " is " + results[i]);
		}
	}

	private static int[] createArrayWithResults(int[] array, IExample ie) {
		if (array != null && ie != null) {
			int[] ret = new int[array.length];
			for (int i = 0; i < array.length; i++) {
				ret[i] = ie.getResult(array[i]);
			}
			return ret;
		}
		return null;
	}
}
