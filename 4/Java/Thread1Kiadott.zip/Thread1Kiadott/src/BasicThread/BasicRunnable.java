package BasicThread;

public class BasicRunnable implements Runnable {

	@Override
	public void run() {
		while (true)
		{
			System.out.println("BasicRunnable");
		}
	}

}
