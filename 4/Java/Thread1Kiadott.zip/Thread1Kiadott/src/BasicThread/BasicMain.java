package BasicThread;

public class BasicMain {

	public static void main(String[] args) {
		
		new Thread(new BasicRunnable()).start();
		
//		(new BasicThread()).start();
		
		while (true)
		{
			System.out.println("BasicMain");
		}
	}

}
