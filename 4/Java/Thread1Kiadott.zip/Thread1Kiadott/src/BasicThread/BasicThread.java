package BasicThread;

public class BasicThread {

	// TODO: kiegészíteni
}
