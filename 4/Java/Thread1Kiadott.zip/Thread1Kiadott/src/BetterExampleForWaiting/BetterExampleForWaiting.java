package BetterExampleForWaiting;

import PortEmulator.*;

/**
 * Egy jobb példa várakozásra.
 */
public class BetterExampleForWaiting {

	public static void main(String[] args) throws InterruptedException {
		// Port emulátor, majd később megnézzük, hogyan is működik.
		// Lényege, hogy időnként kapunk adatokat rajta keresztül, 
		// de általában várni kell.
		PortEmulator port = new PortEmulator(0.5f);
		
		while(true)
		{
			// A sleep nem blokkolja a processzort, hanem átadja a futás lehetőségét más szálaknak
			Thread.sleep(200); // Ennyi időnként akarjuk megnézni, hogy jött-e adat 
			while (!port.isEmpty())
			{
				// Ha jött adat, akkor amíg ki nem szedek mindent
				System.out.println("Adat jött: "+port.get());
			}
		}
	}

}
