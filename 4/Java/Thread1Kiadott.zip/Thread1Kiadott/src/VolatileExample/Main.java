package VolatileExample;

/**
 * Program, ami demonstrálja a volatile működését.
 * @author sulan
 *
 * Két szál ér el egy globális változót, az egyik inkrementálja, a másik olvassa. Mivel csak egy
 * szál ír, ezért nincs szükség szinkronizációra.
 *
 * Ha a változó nem volatile, akkor előfordulhat, hogy a szálak becache-elik maguknak a változót,
 * és nem figyelnek rá, hogy a főmemóriába kiírják vagy onnan olvassák a megváltozott értéket.
 * Sajnos ez nem feltétlen fordul elő, attól függően, hogy a környezet hogy hajtja végre a kódot.
 */
public class Main {

  /**
   * A globális változó, amelyet az egyik szál inkrementál, a másik olvas.
   *
   * Ennek volatile-nak kéne lennie.
   */
  public static int GLOBAL = 0;

  public static void main(String[] args) {
    new ChangeListener().start();
    new ChangeMaker().start();
  }
}
