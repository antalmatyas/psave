package VolatileExample;

/**
 * Egy szál, amely fél másodpercenként inkrementálja a {@link Main#GLOBAL} változót.
 * @author sulan
 */
public class ChangeMaker extends Thread {

  @Override
  public void run() {
    int local = Main.GLOBAL;
    while (Main.GLOBAL < 5) {
      System.out.println("Incrementing to: " + (local + 1));
      Main.GLOBAL = ++local;
      try {
        Thread.sleep(500);
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
    }
  }
}
