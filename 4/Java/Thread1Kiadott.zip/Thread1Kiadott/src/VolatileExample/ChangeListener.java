package VolatileExample;

/**
 * Egy szál, amelyik figyeli, hogy a {@link Main#GLOBAL} megváltozott-e
 * @author sulan
 *
 * A példa kedvéért busy waitinggel.
 */
public class ChangeListener extends Thread {

  @Override
  public void run() {
    int local = Main.GLOBAL;
    while (local < 5) {
      if (local != Main.GLOBAL) {
        System.out.println("Change received: " + Main.GLOBAL);
        local = Main.GLOBAL;
      }
    }
  }
}
