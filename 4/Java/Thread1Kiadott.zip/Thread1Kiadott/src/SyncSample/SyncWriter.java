package SyncSample;

public class SyncWriter extends Thread{
	//Miért nem segít a synchronized?
	synchronized public void run(){ 
		for (int i=0; i<10; i++){
			System.out.println("Edward király, angol király");
			System.out.println("Léptet fakó lován:");
			System.out.println("Hadd látom, úgymond, mennyit ér");
			System.out.println("A velszi tartomány.");
			System.out.println("");
			System.out.println("Van-e ott folyó és földje jó?");
			System.out.println("Legelőin fű kövér?");
			System.out.println("Használt-e a megöntözés:");
			System.out.println("A pártos honfivér?");
			System.out.println("");
		}
	}
	
	public static void main(String[] args){
		for (int i=0; i<10; i++){
			(new SyncWriter()).start();
		}
	}
}
