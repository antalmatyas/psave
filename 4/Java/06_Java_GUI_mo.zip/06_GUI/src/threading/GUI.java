package threading;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class GUI extends Application {
  @Override
  public void start(Stage primaryStage) throws Exception {
    Button button = new Button("Calculate!");
    button.setFont(Font.font(20));
    button.setOnAction(event -> {
      button.setText("Calculating...");
      primaryStage.sizeToScene();
      Thread th = new Thread(new PiCalculation(button));
//    Thread th = new Thread(new PiCalculation2(button));
      th.setDaemon(true);   // Ha minden más szálnak vége, ne számolgasson magában
      th.start();
    });
    primaryStage.setTitle("JavaFX concurrency demo");
    primaryStage.setScene(new Scene(button));
    primaryStage.setOnCloseRequest(event -> System.exit(0));
    primaryStage.show();
  }

  public static void main(String[] args) {
    launch(args);
  }
}
