package threading;

import javafx.concurrent.Task;
import javafx.scene.control.Labeled;

import java.util.Random;

/**
 * Egy háttérszálon futó Task, amely valamilyen pontossággal kiszámolja
 * a pi értékét, majd a számolás végeztével kiírja azt.
 *
 * A call() metódus garantáltan nem a JavaFX Application szálon fut, így
 * nem fagy le az ablak.
 *
 * A succeeded() metódus garantáltan a JavaFX Application szálon fut, így
 * ezen belül módosíthatjuk a GUI-t.
 *
 * Meghívni ugyanúgy kell, mintha egy Runnable objektumot szeretnénk új
 * szálon futtatni.
 */
public class PiCalculation extends Task<Void> {
  private static final long ITERATIONS = 100000000;
  private static final Random random = new Random();

  private final Labeled resultLabel;
  private double result;

  public PiCalculation(Labeled resultLabel) {
    this.resultLabel = resultLabel;
  }

  @Override
  protected Void call() throws Exception {
    result = calculatePi();
    return null;
  }

  @Override
  protected void succeeded() {
    resultLabel.setText("Pi: " + String.valueOf(result));
  }

  private double calculatePi () {
    // Monte Carlo szimuláció

    // azon pontok száma, amelyek egy egység sugarú körnegyeden belül esnek
    long in = 0;
    for (long i = 0; i < ITERATIONS; ++i) {
      double x = random.nextDouble();
      double y = random.nextDouble();
      if (x * x + y * y <= 1) {
        ++in;
      }
    }
    // A körnegyed területe $\pi/4 = in/ITERATIONS$
    return 4 * (double)in / ITERATIONS;
  }
}
