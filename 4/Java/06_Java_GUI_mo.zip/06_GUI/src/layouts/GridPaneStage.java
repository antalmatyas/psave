package layouts;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.RowConstraints;
import javafx.stage.Stage;

public class GridPaneStage extends Stage {

  public GridPaneStage() {
    setTitle("Grid layout");
    GridPane root = new GridPane();
    ColumnConstraints columnConstraints = new ColumnConstraints();
    columnConstraints.setPercentWidth(20);
    columnConstraints.setHgrow(Priority.ALWAYS);
    RowConstraints rowConstraints = new RowConstraints();
    rowConstraints.setPercentHeight(25);
    rowConstraints.setVgrow(Priority.ALWAYS);
    for (int i = 0; i < 4; ++i) {
      for (int j = 0; j < 5; ++j) {
        Button button = new Button("ButtonMatrix" + i + j);
        // Ezektől a gomb fogja kitölteni a rendelkezésre álló helyet
        button.setMaxHeight(Double.MAX_VALUE);
        button.setMaxWidth(Double.MAX_VALUE);
        root.add(button, j, i);
      }
      // Ezektől a layout fogja kitölteni a rendelkezésre álló helyet
      root.getRowConstraints().add(rowConstraints);
    }
    for (int i = 0; i < 5; ++i) {
      root.getColumnConstraints().add(columnConstraints);
    }
    Scene scene = new Scene(root);
    setScene(scene);
    show();
  }
}
