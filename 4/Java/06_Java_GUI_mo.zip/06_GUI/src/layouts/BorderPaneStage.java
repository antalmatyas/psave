package layouts;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class BorderPaneStage extends Stage {
  public BorderPaneStage() {
    setTitle("BorderPane");
    BorderPane root = new BorderPane();
    Button top = new Button("Top");
    root.setTop(top);
    BorderPane.setAlignment(top, Pos.CENTER);

    Button bottom = new Button("Bottom");
    root.setBottom(bottom);
    BorderPane.setAlignment(bottom, Pos.CENTER);

    Button right = new Button("Right");
    root.setRight(right);
    BorderPane.setAlignment(right, Pos.CENTER);

    Button left = new Button("Left");
    root.setLeft(left);
    BorderPane.setAlignment(left, Pos.CENTER);

    Button center = new Button("Center");
    root.setCenter(center);
    BorderPane.setAlignment(center, Pos.CENTER);

    Scene scene = new Scene(root, 200, 200);
    setScene(scene);
    show();
  }
}
