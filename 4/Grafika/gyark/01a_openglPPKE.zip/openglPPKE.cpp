// openglPPKE.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>  



void Init(){

	glViewport(0, 0, 400, 400);
    glMatrixMode(GL_MODELVIEW);    
    glLoadIdentity( );
    glMatrixMode(GL_PROJECTION);   
    glLoadIdentity( );
    gluOrtho2D(0., 100., 0., 100.); 
	
}

void ReDraw( ) { 
    glClearColor(0, 0, 0, 0); //h�tt�rsz�n
    glClear(GL_COLOR_BUFFER_BIT);
    
	/*
	Rajzold ki az aktu�lis poligont
	*/

	//itt most egy z�ld h�romsz�get rajzolunk
	glColor3d( 0.0, 1.0, 0.0 );  
	glBegin(GL_TRIANGLES);
		glVertex2d(10.0, 10.0);
		glVertex2d(20.0, 100.0);
		glVertex2d(90.0, 30.0);
	glEnd( );

	glFlush( ); //Azonnal jelen�tse meg
}



//Az ablak �tm�retez�s�n�l sk�l�zza a k�pet is
void reshape(int w, int h) {
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,100,0.0,100);
}

void Keyboard(unsigned char key, int x, int y) {

	/* h eset�n v�ltson h�romsz�gre n eset�n n�gysz�gre*/
	

	glutPostRedisplay(); //�jra rajzolja ki az ablakot
}


int _tmain(int argc, _TCHAR* argv[])
{
    glutInitWindowSize(400, 400);
    glutInitWindowPosition(100, 100);
    glutInit(&argc, argv);
    glutInitDisplayMode( GLUT_RGB );
    glutCreateWindow("Square_and_triangle");
	Init();

    glutKeyboardFunc( Keyboard );
    glutDisplayFunc( ReDraw );
	glutReshapeFunc(reshape);	
	
    glutMainLoop();

}



