// openglPPKE.cpp : t�rt�ttvonal rajzol� keretrendszer @ Benedek Csaba PPKE ITK 2010
//

#include "stdafx.h"
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h> 


#define MAXARRAYSIZE 100

//T�r�ttvonal egyes pontjainak x ill y koordin�t�it tartalmaz� t�mb: (lehet m�shogy is reprezent�lni...)
int xcoord[MAXARRAYSIZE];
int ycoord[MAXARRAYSIZE];
int ptNum=0;

//Ablakm�ret:
int wH=400;
int wW=400;

//Saj�t glob�lis v�lzot�k:
/*
.....
*/


//Ide �rj, ha van saj�t inicializ�l�si feladat
void SajatInit() {
	/*
	.......
	*/
}


//�jrarajzol�s
void ReDraw( ) { 
    //Feh�r h�tt�r:
	glClearColor(1.0, 1.0, 1.0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    

	//Fekete t�rt�tt vonal kirajzol�sa:
	/*
	.......
	*/

	glFlush( );
}





//Eg�r mozg�ra aktiv�l�dik, kurzorpoz�ci� koordin�t�it kapja bemenetnek
void Motion(int x, int y) {
	
	
}


void MouseFunction(int button, int state, int x,int y) 
{
	
	//bal gomb lenyom�s�ra
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN /*&& ... */) {
			/*
			.....
			*/		
	}

	//jobb gomb lenyom�s�ra/felenged�s�re (l�sd 2.2 feladat)
	if (button == GLUT_RIGHT_BUTTON) {
		if  (state == GLUT_DOWN) {
			/*...*/
		} else {
			/*...*/
		}
	}

	//A k�perny� �jrarajzol�sa (azaz redraw h�v�sa)
	glutPostRedisplay();
}






void Keyboard(unsigned char key, int x, int y) {
  
	switch(key) { 
		case 'c':
			//t�rl�s
			/*
			...
			*/
			break;
		case '1':
			//vonalvastags�g legyen 1...
			/*
			...
			*/
			break;
			/*
			...
			stb billenty�zet funcki�k
			...
			*/
		case 27: 
			exit(0); 
			break; 
	   default: 
       break; 
   } 
	//A k�perny� �jrarajzol�sa (azaz redraw h�v�sa)
	glutPostRedisplay();
}



//--------------------------
//  Keret (nem kell m�dos�tani)

//Inicializ�l�s
void Init(){
	glViewport(0, 0, wW, wH);
    glMatrixMode(GL_MODELVIEW);    
    glLoadIdentity( );
    glMatrixMode(GL_PROJECTION);   
    glLoadIdentity( );
	gluOrtho2D(0.0, wW, wH, 0.0); 
	SajatInit();
}

//Ablak �tm�retez�sekor a teljes k�pet sk�l�zza
void reshape(int w, int h) {
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0, wW, wH, 0.0);
	wW=w;
	wH=h;
}

int _tmain(int argc, _TCHAR* argv[])
{
	wW=400;
	wH=400;
    glutInitWindowSize(wW, wH);
    glutInitWindowPosition(100, 100);
    glutInit(&argc, argv);
    glutInitDisplayMode( GLUT_RGB );
    glutCreateWindow("DrawLine");
	Init();

    glutKeyboardFunc( Keyboard );
    glutDisplayFunc( ReDraw );
	glutMouseFunc(MouseFunction);
	glutMotionFunc(Motion);
	glutReshapeFunc(reshape);	
    glutMainLoop();
}

