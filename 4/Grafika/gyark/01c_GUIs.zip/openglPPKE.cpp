// openglPPKE.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "stdafx.h"
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>  



void Init(){


	

	GLfloat light_position[] = {0.0, 0.0, -1.0, 1.0 };

	glLightfv( GL_LIGHT0, GL_POSITION, light_position );
	glEnable(GL_LIGHT0);

	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);
}



void ReDraw( ) { 
    
	glEnable(GL_LIGHTING);
	glClearColor (1.0, 1.0, 1.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();
	glRotatef(-20, 1.0, 0.0, 0.0);
	glRotatef(30, 0.0, 1.0, 0.0);

	float GreenSurface[]={1.0,0.0,0.0,1.0};
	glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,GreenSurface);
	
	/*
	Ide kell �rni a GLUT rajzol� primit�veket
	*/
	glutSwapBuffers();
}


void reshape(int w, int h) {
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,100,0.0,100);
}





void MenuFunc(int menuItemIndex) {


	/*Itt ki kell eg�sz�teni az egyes eseteket!!!*/
	switch(menuItemIndex) {
		case 0:  break;
		case 1: break;
		case 2:  break;
		case 3:  break;
		case 4: exit(0);
		case 5: MessageBox(NULL,"Hello Glut", "About",MB_OK); break;
	}

	glutPostRedisplay();

}
int _tmain(int argc, _TCHAR* argv[])
{
    glutInitWindowSize(600, 600);
    glutInitWindowPosition(100, 100);
    glutInit(&argc, argv);
	glutInitDisplayMode( GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH );
    glutCreateWindow("MenuDraw");
	
	Init();

    glutDisplayFunc( ReDraw );



	/*
	Ide kell implement�lni a men� l�trehoz�s�t
	*/
	

	glutMainLoop();

}

