/*
 * File:   main_stepByStep.cpp
 * Author: polpe
 *
 * Created on February 10, 2014, 3:24 PM
 */

#include <cstdlib>
#include <iostream>

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>

#define MAXPTNUM 100


double knotVector[MAXPTNUM];
GLfloat ctrlpoints[MAXPTNUM][3];

int	sizeX;
int	sizeY;

int ptnum;

bool animate=false;

double t_par=0;
double felosztas=1000;
void init(void)
{


   glClearColor(1.0, 1.0, 1.0, 1.0);
   glShadeModel(GL_FLAT);

   glEnable(GL_MAP1_VERTEX_3);

   glViewport(0, 0, (GLsizei) sizeX, (GLsizei) sizeY);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();

  gluOrtho2D(0,sizeX,sizeY,0);

   ptnum=0;
}

double L( int i, double tt ) {
	double Li = 1.0;
	for(int j = 0; j < ptnum; j++) {
		if (i != j) Li *= (tt - knotVector[j]) / (knotVector[i] -knotVector[j]);
	}
	return Li;
}


void keyboard(unsigned char key, int x, int y)
{
	switch(key) {

		case 's':
			animate=true;
			/*init animation*/
			break;

		case 'd':
			animate=false;
		break;


	}
}


void DrawLagrangePoint(float t) {

	GLfloat ptx=0; GLfloat pty=0;
      for(int i = 0; i < ptnum; i++) {
		double lit= L(i,t);
		ptx+=ctrlpoints[i][0]*L(i,t);
		pty+=(ctrlpoints[i][1])*L(i,t);
	}
	glVertex2f(ptx,pty);
}

void CalcLagrangePoint(float t, float *xcoord,float *ycoord) {
	GLfloat ptx=0; GLfloat pty=0;
      for(int i = 0; i < ptnum; i++) {
		double lit= L(i,t);
		ptx+=ctrlpoints[i][0]*L(i,t);
		pty+=(ctrlpoints[i][1])*L(i,t);
	}
	*xcoord=ptx;
	*ycoord=pty;
}

int actMovePt=-1;
int isRighButtonPressed=0;
int movePoint=0;
int movePointOffsetX=0;
int movePointOffsetY=0;


int distThresh2=1000;
int ChooseClosestPoint(int x, int y) {
	int mindist2=sizeX*sizeX+sizeY*sizeY;
	int minind=-1;
	for (int i=0;i<=ptnum;i++) {
		int actDist2=(ctrlpoints[i][0]-x)*(ctrlpoints[i][0]-x)+(ctrlpoints[i][1]-y)*(ctrlpoints[i][1]-y);
		if (actDist2<distThresh2 && actDist2<mindist2) {
			mindist2=	actDist2;
			minind=i;
		}
	}

	return minind;
}

void Motion(int x, int y) {
	if (isRighButtonPressed && actMovePt>=0) {
		ctrlpoints[actMovePt][0]=x+movePointOffsetX;
		ctrlpoints[actMovePt][1]=y+movePointOffsetY;
		glutPostRedisplay();
	}
}

void MouseFunction(int button, int state, int x,int y)
{

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {

		ptnum++;
		ctrlpoints[ptnum-1][0]=x;
		ctrlpoints[ptnum-1][1]=y;
		ctrlpoints[ptnum-1][2]=0;


	}
	if (button == GLUT_RIGHT_BUTTON) {
		if  (state == GLUT_DOWN) {
			isRighButtonPressed=true;
			actMovePt=ChooseClosestPoint(x,y);
		} else {
			isRighButtonPressed=false;
			actMovePt=-1;
		}
	}
	glutPostRedisplay();
}


void Step() {
	if (animate) {

		/*Step the animation before rendering the new scene*/
		glutPostRedisplay();
	}
}


void display(void)
{
   int i;



   for (int i=0;i<ptnum;i++) {
		knotVector[i]=(double)i/(double(ptnum-1));
   }

   glClear(GL_COLOR_BUFFER_BIT);
   glColor3f(0.0, 0.0, 0.0);


   int beosztas=100;

   if (ptnum>=2) {
	glBegin(GL_LINE_STRIP);
	for (int i=0;i<beosztas;i++) {
		DrawLagrangePoint(((float)i)/((float)(beosztas-1)));
	}
	glEnd();
   }


   if (animate) {

		/*Draw car in correct position*/


   }
   else {
	glPointSize(8.0);
	glColor3f(1.0, 0.0, 0.0);
	glBegin(GL_POINTS);
	for (i = 0; i < ptnum; i++)  {
		glVertex3fv(&ctrlpoints[i][0]);

	}
	glEnd();
   }

   glFlush();
	glutSwapBuffers();
}




int main(int argc, char* argv[])
{
	sizeX=500;
	sizeY=500;

   glutInit(&argc, argv);
     glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
   glutInitWindowSize (sizeX, sizeY);
   glutInitWindowPosition (100, 100);
   glutCreateWindow (argv[0]);
   init ();
   glutDisplayFunc(display);
   glutMouseFunc(MouseFunction);
   glutMotionFunc(Motion);
   glutKeyboardFunc (keyboard);
   glutIdleFunc(Step);
   glutMainLoop();
   return 0;
}



