/*
 * File:   main_stepByStep.cpp
 * Author: polpe
 *
 * Created on February 10, 2014, 3:24 PM
 */

#include <cstdlib>
#include <iostream>

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/glut.h>

void Init(){




	GLfloat light_position[] = {0.0, 0.0, -1.0, 1.0 };

	glLightfv( GL_LIGHT0, GL_POSITION, light_position );
	glEnable(GL_LIGHT0);

	glDepthFunc(GL_LEQUAL);
	glEnable(GL_DEPTH_TEST);
}



void ReDraw( ) {

	glEnable(GL_LIGHTING);
	glClearColor (1.0, 1.0, 1.0, 0.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glLoadIdentity();
	glRotatef(-20, 1.0, 0.0, 0.0);
	glRotatef(30, 0.0, 1.0, 0.0);

	float GreenSurface[]={1.0,0.0,0.0,1.0};
	glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,GreenSurface);

	/*
	Ide kell �rni a GLUT rajzol� primit�veket
	*/
	glutSwapBuffers();
}


void reshape(int w, int h) {
	glViewport(0,0,(GLsizei)w,(GLsizei)h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(0.0,100,0.0,100);
}





void MenuFunc(int menuItemIndex) {


	/*Itt ki kell eg�sz�teni az egyes eseteket!!!*/
	switch(menuItemIndex) {
		case 0:  break;
		case 1: break;
		case 2:  break;
		case 3:  break;
		case 4: exit(0);
	}

	glutPostRedisplay();

}
int main(int argc, char* argv[])
{
    glutInitWindowSize(600, 600);
    glutInitWindowPosition(100, 100);
    glutInit(&argc, argv);
	glutInitDisplayMode( GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH );
    glutCreateWindow("MenuDraw");

	Init();

    glutDisplayFunc( ReDraw );



	/*
	Ide kell implement�lni a men� l�trehoz�s�t
	*/


	glutMainLoop();

}

